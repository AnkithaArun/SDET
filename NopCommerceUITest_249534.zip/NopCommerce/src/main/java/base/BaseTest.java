package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import pages.ShowHomePage;
import utilities.FileIO;

public class BaseTest {
	
	static WebDriver driver;
	public static Properties SERV_PROP_FILE;
	public static String browserChoice;

	public BaseTest() {
		SERV_PROP_FILE = FileIO.initProperties();
	}
	
	@BeforeMethod
	public WebDriver setup() {
		browserChoice = SERV_PROP_FILE.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("edge")) {
			driver = BrowserConfig.getedgebrowser();
		}
		return driver;	
	}
	
	@AfterMethod
    public static void tearDownDriver() {
        driver.close();  // close the default window
        driver.quit();  // close the session
    }

	public ShowHomePage goToHomePage() {
		driver.get(SERV_PROP_FILE.getProperty("Base_Url"));
		Assert.assertEquals(driver.getTitle(), "nopCommerce demo store");
		return PageFactory.initElements(driver, ShowHomePage.class);
	}
	
	public static WebDriver getDriver() {
		return driver;
	}

}
