package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class LoginPage {
	
	private static WebDriver driver;
	WebDriverWait wait;
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id ="Email")
	private WebElement mail;
	@FindBy(id="Password")
	private WebElement pass;
	@FindBy(xpath="//button[@class='button-1 login-button']")
	private WebElement logbtn;
	@FindBy(xpath="//div[@class='message-error validation-summary-errors']")
	private WebElement errormsg;
	@FindBy(xpath="//a[@class='ico-logout']")
	private WebElement logout;
	@FindBy(xpath="//span[@class='forgot-password']")
	private WebElement forgot;
	
	public String actualURL() {
		return driver.getCurrentUrl();
	}
	public static WebDriver returnDriver() {
		return driver;
	}
	
	public void inpMail(String email) {
		mail.sendKeys(email);
	}
	public void inpPass(String password) {
		pass.sendKeys(password);
	}
	public void clickLogin() {
		logbtn.click();
	}
	public String errorMessage() {
		return DriverUtils.getText(errormsg);
	}
	public void clkLogout(){
		logout.click();
	}
	public String getLoginTitle() {
		return driver.getTitle();
	}
	
	public String getLoginButtonText() {
		return DriverUtils.getText(logbtn);
	}
	public String getforgotPasswordText() {
		return DriverUtils.getText(forgot);
	}
	

}
