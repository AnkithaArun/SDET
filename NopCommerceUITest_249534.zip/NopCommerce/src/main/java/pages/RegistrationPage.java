package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class RegistrationPage {
	
	private WebDriver driver;
	WebDriverWait wait;
	public RegistrationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id ="gender-female")
	private WebElement gender;
	@FindBy(id="FirstName")
	private WebElement fname;
	@FindBy(id="LastName")
	private WebElement lname;
	@FindBy(id="Email")
	private WebElement email;
	@FindBy(id="Password")
	private WebElement pass;
	@FindBy(id="ConfirmPassword")
	private WebElement cnfpass;
	@FindBy(id="register-button")
	private WebElement regbtn;
	@FindBy(xpath="//div[@class='result']")
	private WebElement sumsg;

	
	public String actualURL() {
		return driver.getCurrentUrl();
	}
	public void genderClk() {
		gender.click();
	}
	public void inputFirstname(String firstname) {
		fname.sendKeys(firstname);
	}
	public void inputLastname(String lastname) {

		lname.sendKeys(lastname);
	}
	public void inputEmail(String mail) {
		email.sendKeys(mail);
	}
	public void inputPassword(String password) {
		pass.sendKeys(password);
	}
	public void inputConfirmPassword(String cnfpassword) {
		cnfpass.sendKeys(cnfpassword);
	}
	public void registerButton() {
		regbtn.click();
	}
	public String successMsg() {
		return DriverUtils.getText(sumsg);
	}

}
