package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ShowHomePage {
	
	private WebDriver driver;
	@FindBy(xpath = "//a[@class='ico-register']")
	private WebElement regbtn;
	@FindBy(xpath = "//a[@class='ico-login']")
	private WebElement loginbtn;
	@FindBy(xpath="//ul[@class='top-menu notmobile']//a[normalize-space()='Jewelry']")
	private WebElement jwl;
	
	
	public ShowHomePage(WebDriver driver) {
		this.driver = driver;
	}
	public RegistrationPage clickReg() {
		regbtn.click();
		return PageFactory.initElements(driver, RegistrationPage.class);
	}
	public LoginPage clickLogin() {
		loginbtn.click();
		return PageFactory.initElements(driver, LoginPage.class);
	}
	public AddToCart clickjwl() {
		jwl.click();
		return PageFactory.initElements(driver, AddToCart.class);
	}
	
}
