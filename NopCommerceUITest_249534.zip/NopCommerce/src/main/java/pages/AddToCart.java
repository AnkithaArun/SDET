package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class AddToCart {
	private  WebDriver driver;
	public AddToCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	WebDriverWait wait;
	
	@FindBy(xpath="//h2[@class='product-title']//a[normalize-space()='Flower Girl Bracelet']")
	private WebElement product;
	@FindBy(id="add-to-cart-button-41")
	private WebElement atocart;

	
	public String actualURL() {
		return driver.getCurrentUrl();
	}
	public WebDriver driverreturn() {
		return driver;
	}
	public void clkProduct() {
		product.click();
	}
	public void clkAddcart() {
		atocart.click();
	}


}
