package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.AddToCart;
import pages.LoginPage;
import pages.RegistrationPage;
import pages.ShowHomePage;
import utilities.ExcelUtils;
import utilities.FileIO;
@Listeners(utilities.SampleListener.class)
public class NopCommTests extends BaseTest {
	
	WebDriver driver;

	public NopCommTests() {
		SERV_PROP_FILE = FileIO.initProperties();
	}
	
	String[][] data;
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = ExcelUtils.testdata();
		return data;
	}
	
	@DataProvider(name = "testData2")
	public Object[][] testdata2() {
		data = ExcelUtils.testdata2();
		return data;
	}
	
	@Test(priority = 1, dataProvider ="testData")
	public void registerTest(String firstname,String lastname,String mail,String password, String cnfpassword) {
		
		ShowHomePage home = goToHomePage();
		RegistrationPage reg = home.clickReg();
		 
		// Assert URL, elements
				String expected_URL = "https://demo.nopcommerce.com/register?returnUrl=%2F";
				String actual_URL = reg.actualURL();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(expected_URL.equalsIgnoreCase(actual_URL)).isTrue();
				});
				
		reg.inputFirstname(firstname);
		reg.inputLastname(lastname);
		reg.inputEmail(mail);
		reg.inputPassword(password);
		reg.inputConfirmPassword(cnfpassword);
		reg.registerButton();
		
		// Assert the success URL and success message.
				String expected_URL2 = "https://demo.nopcommerce.com/registerresult/1?returnUrl=/";
				String actual_URL2 = reg.actualURL();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(expected_URL2.equalsIgnoreCase(actual_URL2)).isTrue();
				});
				String expected_text = "Your registration completed";
				String actual_text = reg.successMsg();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(expected_text.equalsIgnoreCase(actual_text)).isTrue();
				});
	
	}
	
	@Test(priority = 2, dataProvider="testData2")
	public void loginTest(String email, String password) {
		
		ShowHomePage home = goToHomePage();
		LoginPage log = home.clickLogin();
		// Assert URL
		String expected_URL = "https://demo.nopcommerce.com/login?returnUrl=%2F";
		String actual_URL = log.actualURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_URL.equalsIgnoreCase(actual_URL)).isTrue();
		});
		
		// Check if forgot password button is present on the page.
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(DriverUtils.isElementPresent(log.returnDriver(),
							By.xpath(SERV_PROP_FILE.getProperty("fgtpass")))).isTrue();
				});
		log.inpMail(email);
		log.inpPass(password);
		log.clickLogin();
		// Handle different login scenarios based on provided email and password.
				if (email.equals("ananya@gmail.com") && password.equals("abcdef")) {
					String actual = "Login was unsuccessful. Please correct the errors and try again. No customer account found";
					String expected = log.errorMessage();
					// Verify the error message for a failed login attempt.
					SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
					});
				} else if (email.equals("incorrectmail@gmail.com") && password.equals("ananya123")) {
					String actual = "Login was unsuccessful. Please correct the errors and try again. No customer account found";
					String expected = log.errorMessage();
					// Verify the error message for another failed login attempt.
					SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
					});
				} else if (email.equals("anugraha@gmail.com") && password.equals("anjan1123")) {
					// For successful login, verify that the "Account" text is present.
					SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(DriverUtils.isTextPresent(log.returnDriver(), "nopCommerce demo store")).isTrue();
					});
					// Perform additional actions for a successful login, such as signing out.
					log.clkLogout();
				}

		
	}
	
	@Test(priority = 3)
	public void addCart() {
		ShowHomePage home = goToHomePage();
		AddToCart atc = home.clickjwl();
		
		        // Assert URL
				String expected_URL = "https://demo.nopcommerce.com/jewelry";
				String actual_URL = atc.actualURL();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(expected_URL.equalsIgnoreCase(actual_URL)).isTrue();
				});
				atc.clkProduct();
				// Verify that the "Add to Cart" button is present.
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions
							.assertThat(DriverUtils.isElementPresent(atc.driverreturn(), By
									.xpath(SERV_PROP_FILE.getProperty("addtocart"))))
							.isTrue();
				});
				atc.clkAddcart();
				DriverUtils.delay(1000);
				// Verify the success message after adding to the cart.
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(DriverUtils.isElementPresent(atc.driverreturn(),
							By.xpath(SERV_PROP_FILE.getProperty("atocartmsg")))).isTrue();
				});
	}
	

}
