package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import base.BaseTest;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;
import pages.ShowHomePage;

public class CucumberTests extends BaseTest{
	
	
	public static WebDriver driver;
	public ShowHomePage home;
	public String title;
	public String forgot;
	public String loginbutton;
	
	@Given("the user navigates to the website")
	public void the_user_navigates_to_the_website() {
		driver=setup();
		home = goToHomePage();
	}
	
	@When("user goes to login page")
	public void user_goes_to_login_page() {
		home.clickLogin();
	}

	@Then("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		LoginPage user = new LoginPage(driver);
		title = user.getLoginTitle();
		System.out.println(title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		LoginPage user = new LoginPage(driver);
		title = user.getLoginTitle();
		Assert.assertEquals(title, string);
	}

	@Then("{string} link should be displayed")
	public void link_should_be_displayed(String string) {
		LoginPage user = new LoginPage(driver);
		forgot = user.getforgotPasswordText();
		Assert.assertEquals(forgot, string);
	}

	@Then("{string} button should be displayed")
	public void button_should_be_displayed(String string) {
		
		LoginPage user = new LoginPage(driver);
		loginbutton = user.getLoginButtonText();
		Assert.assertEquals(loginbutton, string);
	}

}
