$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"ae405cb1-4e12-4f7a-b42d-cbccfd9520be","feature":"Login page feature","scenario":"Login page title and Forgot Password link","start":1695987189904,"group":1,"content":"","tags":"","end":1695987198215,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});