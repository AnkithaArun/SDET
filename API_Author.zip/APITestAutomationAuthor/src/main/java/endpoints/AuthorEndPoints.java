package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.AuthorModel;

public class AuthorEndPoints {
	
	public static Response createAuthor(AuthorModel payload) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.baseUri(Routes.baseuri)
				.basePath(Routes.post_basepath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
				
	}
	
	public static Response getAuthor(String idBook) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.baseUri(Routes.baseuri)
				.basePath(Routes.get1_basepath)
				.pathParam("idBook",idBook)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
				
	}
	
	public static Response getAuthor1(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.baseUri(Routes.baseuri)
				.basePath(Routes.get2_basepath)
				.pathParam("id",id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
				
	}
	
	public static Response deleteAuthor(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.baseUri(Routes.baseuri)
				.basePath(Routes.delete_basepath)
				.pathParam("id",id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();
		return response;
				
	}
	public static Response updateAuthor(AuthorModel payload,String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.baseUri(Routes.baseuri)
				.basePath(Routes.put_basepath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;
				
	}
	

}
