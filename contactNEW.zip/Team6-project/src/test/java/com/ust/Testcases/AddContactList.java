package com.ust.Testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI6;
import com.ust.POM.ContactListLogin;
import com.ust.Utilities.ExcelUtils3;

public class AddContactList extends BaseUI6

{
	String[][] data2;
	WebDriver driver;
	ContactListLogin contact;
	@BeforeMethod
	public void setup()
	{
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	@DataProvider(name = "testData3")
	public Object[][] testdata3(String sheet)
	{
		data2= ExcelUtils3.testdata3();
		return data2;
	}
	@Test(dataProvider = "testData3")
	public void AddContact(String email,String password,String firstName1,String lastName1,String DOB,String email1,String phone,String address1,String address2,String District,String State,String Pincode,String Country ) {
		ContactListLogin contact=new ContactListLogin (driver);
		contact.Email(email);
		contact.passWord(password);
		contact.submit();
		contact.addcontact();
		contact.Firstname1(firstName1);
		contact.lastname1(lastName1);
		contact.Dob(DOB);
		contact.Email1(email1);
		contact.ph(phone);
		contact.streets1(address1);
		contact.streets2(address2);
		contact.city(District);
		contact.state(State);
		contact.postal(Pincode);
		contact.country(Country);
		contact.submit2();
	
	}
	
}
