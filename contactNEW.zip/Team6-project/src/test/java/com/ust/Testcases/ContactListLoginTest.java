package com.ust.Testcases;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.ust.Base.BaseUI6;
import com.ust.POM.ContactListLogin;
import com.ust.Utilities.ExcelUtils2;
import com.ust.Utilities.ExcelUtils3;
import com.ust.Utilities.ExcelUtils6;

@Listeners(com.ust.Utilities.SamplrListener.class)

public class ContactListLoginTest extends BaseUI6 
{
	WebDriver driver;
	ContactListLogin cont;
	ContactListLogin cont1;
	String[][] data;
	String[][] data1;
	String[][] data2;
	@BeforeMethod
	public void setup()
	{
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	@DataProvider(name = "testData")
	public Object[][] testdata()
	{
		data= ExcelUtils6.testdata();
		return data;
	}
	@Test(priority=0,dataProvider = "testData")
	public void loginTest(String email,String password)
	{
		ContactListLogin cont=new ContactListLogin (driver);
		cont.Email(email);
		cont.passWord(password);
		cont.submit();
		String a=cont.getURL();
		
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(a.contains("thinking-tester-contact-list.herokuapp.com/contactList"));
		});	
		
		
		String j=cont.errorm();
		
		if((email.equals("incorrectuser")))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j.equalsIgnoreCase("Incorrect username or password"));

			}); 
		}
		else if(password.equals("incorrectPassword"))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j.equalsIgnoreCase("Incorrect username or password"));

			}); 
		}
		else
		{
			
			cont.submit1();
			SoftAssertions.assertSoftly(softAssertions -> {

				softAssertions.assertThat(a.contains("thinking-tester-contact-list.herokuapp.com/addUser"));
			});	
			
			
	}
		
}
	 @DataProvider(name = "testData1")
	public Object[][] testdata1()
	{
		data1= ExcelUtils2.testdata1();
		return data1;
	}
	@Test(priority=2,dataProvider = "testData1")
	public void registerTest(String first,String last,String email,String password)
	{		
		ContactListLogin cont1=new ContactListLogin (driver);
		cont1.submit1();
		cont1.firstName(first);
		cont1.lastName(last);
		cont1.Email(email);
		cont1.passWord(password);
		cont1.submit();
		String j1=cont1.errorm();
		String a1=cont1.getURL();
		
		
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(a1.contains("thinking-tester-contact-list.herokuapp.com/contactList"));
		});

		if((email.equalsIgnoreCase("incorrectuser")))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j1.equalsIgnoreCase("User validation failed: email: Email is invalid"));

			}); 
		}
		else if(password.equals("notco"))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j1.equalsIgnoreCase("User validation failed: password: Path `password` (`notco`) is shorter than the minimum allowed length (7)."));

			}); 
		}
		else if(first.equals("  "))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j1.equalsIgnoreCase("User validation failed: firstName: Path `firstName` is required."));

			}); 
		}
		else if(last.equals("  "))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j1.equalsIgnoreCase("User validation failed: lastName: Path `lastName` is required."));

			}); 
		}
		else if((first.equals("  ")) && (last.equals("  ")))
		{

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j1.equalsIgnoreCase("User validation failed: firstName: Path `firstName` is required., lastName: Path `lastName` is required."));

			}); 
		}
	
}
	@DataProvider(name = "testData3")
	public Object[][] testdata3()
	{
		data2= ExcelUtils3.testdata3();
		return data2;
	}
	@Test(priority=3,dataProvider = "testData3")
	public void AddContact(String email,String password,String firstName1,String lastName1,String DOB,String email1,String phone,String address1,String address2,String District,String State,String Pincode,String Country ) {
		ContactListLogin contact=new ContactListLogin (driver);
		contact.Email(email);
		contact.passWord(password);
		contact.submit();
		contact.addcontact();
		contact.Firstname1(firstName1);
		contact.lastname1(lastName1);
		contact.Dob(DOB);
		contact.Email1(email1);
		contact.ph(phone);
		contact.streets1(address1);
		contact.streets2(address2);
		contact.city(District);
		contact.state(State);
		contact.postal(Pincode);
		contact.country(Country);
		contact.submit2();
		String a2=contact.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(a2.contains("thinking-tester-contact-list.herokuapp.com/contactList"));
		});
		contact.clicktable();
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.id("edit-contact")).isDisplayed());

			 

		});
		contact.clicktreturn();
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.id("add-contact")).isDisplayed());

			 

		});
		contact.clicktable();
		contact.clickdelete();
		contact.clicktreturn();
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.id("logout")).isDisplayed());

			 

		});
		contact.clicklogout();
	
	}
	
}
