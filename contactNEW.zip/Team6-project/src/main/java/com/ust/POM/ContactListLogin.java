package com.ust.POM;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.ust.Base.BaseUI6;
public class ContactListLogin extends BaseUI6 
{
	WebDriver driver;
	public ContactListLogin(WebDriver driver)
	{
		this.driver=driver;
	}
	By email=getlocator("email_id");
	By password=getlocator("password_id");
	By submit=getlocator("submit_id");
	By signup=getlocator("signup_id");
	By addcontactbtn=getlocator("addcontact_id");
	By errormsg=getlocator("error_id");
	By signupmsg=getlocator("signupmsg_id");
	By fname=getlocator("fname_id");
	By lname=getlocator("lname_id");
	By firstname1=getlocator("firstname1_id");
	By lastname1=getlocator("lastname1_id");
	By dOb=getlocator("dob_id");
	By email1=getlocator("email1_id");
	By phone=getlocator("phone_id");
	By street1=getlocator("street1_id");
	By street2=getlocator("street2_id");
	By city=getlocator("city_id");
	By state=getlocator("state_id");
	By postal=getlocator("postal_id");
	By country=getlocator("country_id");
	By submit1=getlocator("submit1_id");
	By table=getlocator("tablerow_xpath");
	By edit=getlocator("edit_id");
	By return1=getlocator("return_id");
	By delete=getlocator("delete_id");
	By logout=getlocator("logout_id");
	public void Email(String mailid) 
	{
		sendtext(email,mailid);
		logger.log(Status.INFO,"Email is entered");
	}
	public void passWord(String pass) 
	{
		sendtext(password,pass);
		logger.log(Status.INFO,"password is entered");
	}
	public void firstName(String first) 
	{
		sendtext(fname,first);
		logger.log(Status.INFO,"fname is entered");
	}
	public void lastName(String last) 
	{
		sendtext(lname,last);
		logger.log(Status.INFO,"lname is entered");
	}
	public void submit() 
	{
		clickOn(submit);
		logger.log(Status.INFO,"submit is clicked");
	}
	 public String getURL()
	{
		String url=driver.getCurrentUrl();
		logger.log(Status.INFO,"url retrieved");
		return url;
	}
	 public String errorm()
	 {	
		 logger.log(Status.INFO,"Errormessage retrieved");
		return rettext(errormsg);
		
	}
	public void submit1() 
	{	
		clickOn(signup);
		logger.log(Status.INFO,"signup is clicked");
	}
	public String SignupMsg()
	{
		logger.log(Status.INFO,"signup message retrieved");
		return rettext(signupmsg);
	}
	
	public void Firstname1(String fname1) {
		sendtext(firstname1,fname1);
		logger.log(Status.INFO,"firstname is entered");
		
	}
	public void lastname1(String lname1) {
		sendtext(lastname1,lname1);
		logger.log(Status.INFO,"lastname is entered");
	}
	public void Dob(String dob) {
		sendtext(dOb,dob);
		logger.log(Status.INFO,"dob is entered");
	}
	public void Email1(String mailid1) {
	   sendtext(email1,mailid1);
	   logger.log(Status.INFO,"email is entered");
	}
	public void ph(String phonenumber) {
	sendtext(phone,phonenumber);
	logger.log(Status.INFO,"phone is entered");
	}
	public void streets1(String address1) {
		sendtext(street1,address1);
		logger.log(Status.INFO,"address1 is entered");
	}
	public void streets2(String address2) {
		sendtext(street1,address2);
		logger.log(Status.INFO,"address2 is entered");
	}
	public void city(String city1) {
		sendtext(city,city1);
		logger.log(Status.INFO,"city is entered");
	}
	public void state(String State) {
		sendtext(state,State);
		logger.log(Status.INFO,"state is entered");
	}
	public void postal(String postalcode) {
		sendtext(postal,postalcode);
		logger.log(Status.INFO,"postalcode is entered");
	}
	public void country(String country1) {
		sendtext(country,country1);
		logger.log(Status.INFO,"country is entered");
	}
	public void submit2() {
	clickOn(submit1);
	logger.log(Status.INFO,"submit clicked");
	}
	public void addcontact() {
	 clickOn(addcontactbtn);
	 logger.log(Status.INFO,"addcontact clicked");
	}
	public void clicktable()
	{
		clickOn(table);
		logger.log(Status.INFO,"contact list  row clicked");
	}
	public void clicktreturn()
	{
		clickOn(return1);
		logger.log(Status.INFO,"return to contact clicked");
	}
	public void clickdelete()
	{
		clickOn(delete);
		logger.log(Status.INFO,"delete clicked");
	}
	public void clicklogout()
	{
		clickOn(logout);
		logger.log(Status.INFO,"logout clicked");
	}
	

}