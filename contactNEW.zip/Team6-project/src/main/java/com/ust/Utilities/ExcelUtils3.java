package com.ust.Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils3 
{

	public static String[][] testdata3() {
	    FileInputStream fis;
	    XSSFWorkbook workbook=null;
	        try
	        {
	        fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\java\\com\\ust\\Resource\\New Microsoft Excel Worksheet.xlsx");
	        workbook=new XSSFWorkbook(fis);
	        }
	        catch(IOException e)
	        {
	            e.printStackTrace();
	        }

	        XSSFSheet sheet=workbook.getSheetAt(2);
	        int rowCount=sheet.getPhysicalNumberOfRows();
	        System.out.println("Total number of rows used in sheet: "+rowCount);
	        int colCount=sheet.getRow(0).getPhysicalNumberOfCells();
	        System.out.println("Total number of columns used in sheet: "+colCount);
	        DataFormatter df=new DataFormatter();
	        String[][] testdata=new String[rowCount][colCount];
	        for (int i = 0; i < rowCount; i++) {
	            for (int j = 0; j < colCount; j++) {

	                testdata[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
	            }

	        }
	        return testdata;

	 

	    }

	
}
