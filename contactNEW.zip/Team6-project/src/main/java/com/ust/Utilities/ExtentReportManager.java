package com.ust.Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ust.Base.BaseUI6;

public class ExtentReportManager extends BaseUI6{
	
	public static ExtentReports extent;
	public static ExtentSparkReporter spark; 
	public static ExtentReports getReportInstance()
	{
		extent=new ExtentReports();
		String repName="TestReport-"+BaseUI6.timestamp+"html";
		spark=new ExtentSparkReporter(System.getProperty("user.dir")+"/TestOutput/"+repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User name", "kirubakaran");
		spark.config().setDocumentTitle("Title of the report comes here");
		spark.config().setReportName("Name of the report comes here ");
		spark.config().setTheme(Theme.DARK);
		return extent;
		
		
	}

}
