$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"ab8f226e-d091-4359-821e-770d6e92cc0f","feature":"Grianger Login Feature","scenario":"Login page title","start":1695289539141,"group":1,"content":"","tags":"","end":1695289557895,"className":"passed"},{"id":"1398b034-c4bd-434f-96ac-d4b147726119","feature":"Grianger Login Feature","scenario":"Forgot UserID link","start":1695289557911,"group":1,"content":"","tags":"","end":1695289574727,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});