package utils;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import base.DriverUtils;

public class SampleListener extends TestListenerAdapter {
	// Static variables to hold the ExtentReports instance and ExtentTest logger
	public static ExtentReports extent;
	public static ExtentTest logger;

	/****************
	 * Getting extent report instance on start of test class
	 ********/
	public void onStart(ITestContext context) {
		extent = ExtentReportManager.getReportInstance();
	}

	/*************
	 * creating test in extent report on start of each test
	 **************/
	public void onTestStart(ITestResult result) {
		// Set the logger in the DriverUtils class for taking screenshots
		logger = extent.createTest(result.getName());
		DriverUtils.logger = logger;
	}

	// Logic for handling a successful test
	public void onTestSuccess(ITestResult result) {
		logger.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
		logger.log(Status.PASS, "Testcase Passed");
		// Logic to capture a screenshot and save it for a passed test
        // This is usually a step for capturing a screenshot when a test passes
        // It uses the DriverUtils class to take a screenshot
		
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filepath = System.getProperty("user.dir") + "//TestOutput//Screenshots//" + folderName + "/" + testName
				+ "/" + testName + "_Passed.png";
		try {
			DriverUtils.takescreenshot(filepath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Logic for handling a failed test
	public void onTestFailure(ITestResult result) {
		logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));
		logger.log(Status.FAIL, "Testcase Failed");
		 // Logic to capture a screenshot and save it for a failed test
        // This is usually a step for capturing a screenshot when a test fails
        // It uses the DriverUtils class to take a screenshot
		
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filepath = System.getProperty("user.dir") + "//TestOutput//Screenshots//" + folderName + "/" + testName
				+ "/" + testName + "_Failed.png";
		try {
			DriverUtils.takescreenshot(filepath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Logic for handling a skipped test
	public void onTestSkip(ITestResult tr) {
		logger = extent.createTest(tr.getName());
		logger.log(Status.SKIP, MarkupHelper.createLabel(tr.getName(), ExtentColor.YELLOW));
		logger.log(Status.SKIP, "Testcase Skipped");
	}

	/*************************
	 * Flushing teh extent report at the end of the test class
	 **************/
	public void onFinish(ITestContext testContext) {
		extent.flush();
	}
}