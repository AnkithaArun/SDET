//defines the package name where this Java class resides.
package base;

//lines import necessary classes related to WebDriver and browser options.
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

//This line declares a public class named BrowserConfig and a static WebDriver variable named driver.
public class BrowserConfig {
	static WebDriver driver;

	//initializes an EdgeDriver with these options, maximizes the browser window, and returns the WebDriver instance.
	public static WebDriver getEdgeBrowser() {

		EdgeOptions options = new EdgeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--remote-allow-origins=*");
		driver = new EdgeDriver(options);
		driver.manage().window().maximize();
		return driver;
	}

	//initializes Chrome browser with these options, maximizes the browser window, and returns the WebDriver instance.
	public static WebDriver getChromeBrowser() {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		return driver;
	}

}
