//defines the package name where this Java class resides.
package base;

import java.time.Duration;
import java.util.Properties;

//import necessary packages and classes for the Selenium WebDriver, TestNG annotations, and other utilities.
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.ShowHomePage;
import utils.FileIO;

//declares a public class named BaseTest.
public class BaseTest {

	/*declare static variables for WebDriver (driver), properties file (SERV_PROP_FILE),
	 *  and browser choice (browserChoice).*/
	
	protected static WebDriver driver;
	public static Properties SERV_PROP_FILE;
	public static String browserChoice;

	/*This is the constructor of the BaseTest class. 
	 * It initializes SERV_PROP_FILE by calling initProperties() from the FileIO class.*/
	
	public BaseTest() {

		SERV_PROP_FILE = FileIO.initProperties();

	}

	/***************** invoke browser **************/

	/* indicating that it should run before each test method.
	 *  It sets up the browser based on the specified choice in the properties file.*/
	
	@BeforeMethod

	public void setup() {

		browserChoice = SERV_PROP_FILE.getProperty("browserName");

		if (browserChoice.equalsIgnoreCase("chrome")) {

			driver = BrowserConfig.getChromeBrowser();

			

		}
	//return driver;

	}
	
	/*This method navigates to the home page, waits for the title to match a specific value, 
	 * performs an assertion on the title, and returns a ShowHomePage object.*/
	
	public ShowHomePage goToHomePage() {
		driver.get(SERV_PROP_FILE.getProperty("AppUrl"));
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Grainger Industrial Supply - MRO Products, Equipment and Tools"));
		Assert.assertEquals(driver.getTitle(),"Grainger Industrial Supply - MRO Products, Equipment and Tools");
		return PageFactory.initElements(driver, ShowHomePage.class);
	}
	
	/* It sets up the WebDriver and returns it.*/
	
	public WebDriver setup1() {

		browserChoice = SERV_PROP_FILE.getProperty("browserName");

		if (browserChoice.equalsIgnoreCase("chrome")) {

			driver = BrowserConfig.getChromeBrowser();

			

		}
	return driver;

	}
	
	public static WebDriver getDriver() {
		return driver;
	}
	
//	@AfterMethod
//	public void closeDriver() {
//		driver.close();
//	}
}
