//defines the package name where this Java class resides.
package base;

import java.io.File;

/*import necessary classes, including Selenium WebDriver-related classes,
for interacting with web elements and handling browser actions.*/

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.PumpsPage;
import utils.DateUtils;
import utils.FileIO;

// declares a public class named DriverUtils.
public class DriverUtils {

	/*
	 * declare static variables for WebDriver (driver), properties file
	 * (SERV_PROP_FILE), and a JavascriptExecutor (js) to execute JavaScript code.
	 */

	private static WebDriver driver;
	public static Properties SERV_PROP_FILE;
	private static JavascriptExecutor js;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();

	/*
	 * This is a constructor for the DriverUtils class. It initializes
	 * SERV_PROP_FILE by calling initProperties() from the FileIO class.
	 */

	public DriverUtils() {
		SERV_PROP_FILE = FileIO.initProperties();

	}

	/*
	 * This constructor takes a WebDriver instance and initializes static variables
	 * driver and js accordingly.
	 */

	public DriverUtils(WebDriver driver) {
		DriverUtils.driver = driver;
		DriverUtils.js = (JavascriptExecutor) driver;

	}

	/*
	 * This method checks if an element is present on the web page using its locator
	 * (By). It returns true if the element is displayed, otherwise false.
	 */

	public static boolean isElementPresent(WebDriver driver, By by) {
		try {
			WebElement element = driver.findElement(by);
			return element.isDisplayed();
		} catch (org.openqa.selenium.NoSuchElementException e) {
			return false;
		}
	}

	// performs a click action on a specific WebElement using the Actions class.
	public static void clickAt(WebDriver driver, WebElement element) {
		Actions builder = new Actions(driver);
		Action action = builder.moveToElement(element).click().build();
		action.perform();
	}

	/**************** drop down handling *****************/

	// This method handles dropdowns by selecting an option based on visible text
	public static void dropDownHandling(WebElement element, String value) {

		try {

			// new WebDriverWait(driver,
			// Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));

//			WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
//			wait.until(ExpectedConditions.visibilityOf(element));

			Select s = new Select(element);

			s.selectByVisibleText(value);

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	// This method introduces a delay in the test script by sleeping for the
	// specified number of seconds.
	public static void delay(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	// This method clears the input field and types the specified text into it.
	public static void clearAndType(WebElement field, String text) {
		field.clear();
		field.sendKeys(text);
	}

	// This method scrolls down the webpage by a specified number of pixels using
	// JavaScript.
	public static void scrollDown(int pixelsToScroll, WebDriver driver) {
		js = (JavascriptExecutor) driver;
		String script = String.format("window.scrollBy(0, %d)", pixelsToScroll);
		js.executeScript(script);
	}

	// Element present or not

	/*
	 * This method checks if an element, identified by the provided By locator, is
	 * present on the web page. It uses a try-catch block to handle any exceptions
	 * that may occur if the element is not found or there are other issues.
	 */

	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	// This method checks if the given text is present in the body of the web page.
	public static boolean isTextPresent(WebDriver driver, String Text) {
		try {
			return driver.findElement(By.tagName("body")).getText().contains(Text);
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/*
	 * This method performs a click operation on a web element using JavaScript. It
	 * uses the JavascriptExecutor to execute JavaScript to click on the element.
	 * The method uses Thread.sleep to introduce a delay, which may not be the best
	 * practice, but it's used here for simplicity.
	 */

	public static void jsClick(WebElement element, WebDriver driver) throws InterruptedException {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		((RemoteWebDriver) executor).executeScript("arguments[0].click();", element);
	}

	// This method retrieves the text of a web element.
	public static String getText(WebElement element) {
		return element.getText(); // method on the element to get the visible text.
	}

	/*
	 * retrieves the text of a web element. If an exception occurs during the
	 * retrieval of the text, it prints the stack trace and returns null. This
	 * method returns the text as a string.
	 */

	public static String getText1(WebElement element) {

		String text = null;

		try {

			text = element.getText();

		} catch (Exception e) {

			e.printStackTrace();

		}

		return text;

	}

	public static void takescreenshot(String filePath) {
		 try {
		 File src = ((TakesScreenshot) BaseTest.getDriver()).getScreenshotAs(OutputType.FILE);
		 FileUtils.copyFile(src, new File(filePath));
		 } catch (Exception e) {
		 e.printStackTrace();
		 }
	}


}
