package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class ShowHomePage {

	private WebDriver driver;

	@FindBy(className = "gcom__header-user-register-link")
	private WebElement register;

	@FindBy(xpath = "//img[@alt='Plumbing & Pumps']")
	private WebElement pumps;

	@FindBy(xpath = "/html/body/main/div/div/footer/div/div[1]/div/div[1]/div[1]/ul/li[1]/a")
	private WebElement career;

	@FindBy(xpath = "//input[@class='gcom__typeahead-query-field']")
	private WebElement searchbar;

	@FindBy(xpath = "//a[@class='gcom__header-bulk-order-link']")
	private WebElement bul;
	
	@FindBy(id="gcom__header-user-sign-in-flyout")
	private WebElement signin;

	@FindBy(className = "gcom__typeahead-submit-button") // button[@class=\"gcom__typeahead-submit-button\"]")
	WebElement searchbtn;

	public ShowHomePage(WebDriver driver) {
		this.driver = driver;
	}

	public RegistrationPage clickRegistrationlink() {
		register.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Registration"));
		return PageFactory.initElements(driver, RegistrationPage.class);
	}

	public PumpsPage clickPumpslink() {
		pumps.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Grainger Industrial Supply - MRO Products, Equipment and Tools"));
		return PageFactory.initElements(driver, PumpsPage.class);
	}

	public CareerPage clickCareerlink() {
		DriverUtils.scrollDown(3000, driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(career));
		career.click();

		wait.until(ExpectedConditions.titleIs("Jobs with Grainger Businesses"));
		return PageFactory.initElements(driver, CareerPage.class);
	}

	public SearchResult enterBtn() {
		searchbtn.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("T-Shaped Miniature Light Bulbs - Grainger Industrial Supply"));
		return PageFactory.initElements(driver, SearchResult.class);
	}
	
	public bulkorder bulorderClick() {
		bul.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Bulk Order Pad"));
		return PageFactory.initElements(driver, bulkorder.class);
		
	}
	
	public SignInPage clickSignIn() {
		signin.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Sign In"));
		return PageFactory.initElements(driver, SignInPage.class);
	}

	public void enterserch(String text) {
		searchbar.sendKeys(text);
	}

	public WebDriver getDriver() {
		return driver;
	}

}
