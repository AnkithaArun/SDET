/*class represents a page in a web application related to a dashboard. 
 * It provides a method to retrieve the text of a button (in this case, the "Continue" button). 
 * The class follows the Page Object Model (POM) design pattern, where it encapsulates the functionality related
 *  to this page, making it easier to manage and maintain the automation code.
*/



// package name where this Java class resides.
package pages;

//import necessary classes and annotations related to Selenium WebDriver and WebElement locating.
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

//declares a public class named DashBoardPage
public class DashBoardPage {
	
	//This line declares a WebDriver instance.
	WebDriver driver;
	
	//annotation uses @FindBy to locate a WebElement using its XPath.
	@FindBy(xpath = "//button[@data-testid='continue']")
	private WebElement continuebutton;
	
	//This is the constructor for the DashBoardPage class. It initializes the driver instance.
	public DashBoardPage(WebDriver driver) {
		this.driver=driver;
	}
	
	//This method retrieves the text of the continue button and returns it as a string.
	public String getName() {
		return continuebutton.getText();
		
	}

}
