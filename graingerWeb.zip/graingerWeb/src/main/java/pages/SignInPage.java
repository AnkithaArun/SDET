package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.DriverUtils;

public class SignInPage {
	
	private  WebDriver driver;
	
	@FindBy(xpath = "//a[@data-test='signin-forgot-user-id']")
	private WebElement forgotUserID;
	
	@FindBy(id="signin_username")
	private WebElement userid;
	
	@FindBy(id="signin_password")
	private WebElement password;
	
	@FindBy(xpath = "//button[@data-test='signin-submit-button']")
	private WebElement submit;
	
	public SignInPage(WebDriver driver ) {
		this.driver=driver;
	}
	
	public String getPageTitle() {
		return driver.getTitle();
	}
	
	public String getForgotUser() {
//		return forgotUserID.getText();
		return DriverUtils.getText(forgotUserID);
		
	}
	
	public void typeUserId(String text) {
		userid.sendKeys(text);
		
	}
	
	public void typePasswordId(String text) {
		password.sendKeys(text);
		
	}
	
	public void clickSubmit() {
		submit.click();
		
	}
	
	public  WebDriver getdriver() {
		return driver;
		
	}

}
