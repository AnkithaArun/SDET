/*represents a page in a web application related to career opportunities. 
 * It provides methods to interact with the page elements, such as entering keywords, cities, clicking search,
 *  selecting job positions, and applying for a job. 
 *  The methods are designed to chain actions together for ease of use and follow the
 *   Page Object Model (POM) design pattern.*/



// defines the package name where this Java class resides.
package pages;

/*import necessary classes and annotations related to Selenium WebDriver, WebElement locating, and waiting.*/
import java.time.Duration;

import org.checkerframework.checker.units.qual.t;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Factory;

import base.DriverUtils;

// declares a public class named CareerPage.
public class CareerPage {
	
	//declares a private WebDriver instance.
	private WebDriver driver;
	
	/*These annotations use the @FindBy annotation to locate WebElements based on their IDs or XPaths.*/
	@FindBy(id = "keywordsearch-q")
	private WebElement keyword;
	
	@FindBy(id = "keywordsearch-locationsearch")
	private WebElement city;
	
	@FindBy(xpath = "//button[@aria-label='Close']")
	private WebElement close;
	
	@FindBy(xpath = "//input[@title='Search']")
	private WebElement search;
	
	@FindBy(xpath = "//tbody//tr[3]//span[@class='jobTitle hidden-phone']//a")
	private WebElement saleRep;
	
	@FindBy(xpath = "//div[@aria-hidden='true']//div[@class='applylink pull-right']")
	private WebElement applynow;
	
	//This is the constructor for the CareerPage class. It initializes the driver instance.
	public CareerPage(WebDriver driver) {
		this.driver=driver;
	}
	
	//This method enters text into the "Keyword" field in the career page.
	public CareerPage typeKeyword(String text) {
		keyword.sendKeys(text);
		return this;
		
	}
	
	//This method enters text into the "City" field in the career page.
	public CareerPage typeCity(String text) {
		city.sendKeys(text);
		return this;
	}
	
	/*This method clicks the "Search" button on the career page after scrolling and clicking using JavaScript.*/
	public CareerPage clickSearch() throws InterruptedException {
		//close.click();
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(search));

		DriverUtils.scrollDown(400, driver);
		DriverUtils.jsClick(search, driver);
		return this;
		
	}
	
	//This method clicks a specific job link on the career page for a sales representative.
	public CareerPage clickSalesRep() {
		saleRep.click();
		return this;
	}
	
	//This method clicks the "Apply Now" button on the career page.
	public CareerPage clickApply() {
		applynow.click();
		return this;
	}
	
	//This method returns the current URL of the page.
	public String getBaseURL() {
		return driver.getCurrentUrl();
	}
	
	

}
