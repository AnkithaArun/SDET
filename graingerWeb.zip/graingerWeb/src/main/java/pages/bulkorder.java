//defines the package name where this Java class resides
package pages;

// import necessary classes and annotations related to Selenium WebDriver and the PageFactory.
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

//declares a public class named bulkorder.
public class bulkorder {
	
	//instance to wait for elements.
	private WebDriver driver;
	WebDriverWait wait;

	/*This is the constructor for the bulkorder class. It initializes the driver, 
	 * sets up a WebDriverWait, and initializes elements using PageFactory.*/
	
	public bulkorder(WebDriver driver) {
		this.driver = driver;

		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}
	
	// This block defines a WebElement bulorder and a method item() to enter an item name by sending keys.
	@FindBy(xpath = "//input[@id='bulk-order-form__sku0']")
	WebElement bulorder;

	public bulkorder item(String i) {
		bulorder.sendKeys(i);
		return this;

	}
	
	/*Similar to the previous block, this defines another WebElement bulorder1 and
	 *  a method item1() to enter another item name.*/
	@FindBy(xpath = "//input[@id='bulk-order-form__sku1']")
	WebElement bulorder1;

	public bulkorder item1(String j) {
		bulorder1.sendKeys(j);
		return this;

	}

	/* to enter quantity, This block defines a WebElement qty and a method quantity() to enter the quantity 
	 * using a utility method clearAndType() from DriverUtils. */
	
	@FindBy(xpath = "//input[@id='bulk-order-form__qty0--quantity']")
	WebElement qty;

	public bulkorder quantity() {
		DriverUtils.clearAndType(qty, "15");
		return this;
	}

	/*Similar to the previous block, this defines another WebElement qty1
	 *  and a method quantity1() to enter another quantity.*/
	
	@FindBy(xpath = "//input[@id='bulk-order-form__qty1--quantity']")
	WebElement qty1;

	public bulkorder quantity1() {
		DriverUtils.clearAndType(qty1, "12");
		return this;

	}

	/* defines a WebElement addcart and a method cartclk() to click on the "Add to Cart" button.*/
	
	@FindBy(xpath = "//button[@id='bulk-order-form__add-to-cart']")
	WebElement addcart;

	public void cartclk() {

		addcart.click();
	}
	
	
	// enter username
		@FindBy(xpath = "//input[@data-test='signin-username-text-input']")
		WebElement name;

		public bulkorder nameEnter(String s) {
			name.sendKeys(s);
			return this;
		}

		// enter password
		@FindBy(xpath = "//input[@data-test='signin-password-text-input']")
		WebElement password;

		public bulkorder passwordEnter(String p) {
			password.sendKeys(p);
			return this;
		}

		// click submit
		@FindBy(xpath = "//button[@data-test='signin-submit-button']")
		WebElement sub;
		
		public bulkorder submitclick() {
			sub.click();
			return this;
		}
}
