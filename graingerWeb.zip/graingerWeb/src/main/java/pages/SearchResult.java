package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class SearchResult {

	private WebDriver driver;
	WebDriverWait wait;

	public SearchResult(WebDriver driver) {
		this.driver = driver;

	}

	@FindBy(xpath = "//input[@data-testid='input-checkbox-1719781']")
	WebElement watts;

	public SearchResult wattsclick() throws InterruptedException {
		DriverUtils.jsClick(watts, driver);
		//DriverUtils.scrollDown(300, driver);
		return this;
	}

	// click on led

	@FindBy(xpath = "//input[@id='browse-filter-group__filter-checkbox--attrslighttechnologyled']")
	WebElement led;

	public SearchResult ledclk() throws InterruptedException {
		DriverUtils.jsClick(led, driver);
		return this;
	}

	// click on add to cart

	@FindBy(xpath = "//form[@data-testid='add-to-cart-form-797UD9']//button")
	WebElement cart;

	public SearchResult cartclick() {
		cart.click();
		return this;
	}

	// enter username
	@FindBy(xpath = "//input[@data-test='signin-username-text-input']")
	WebElement name;

	public SearchResult nameEnter(String s) {
		name.sendKeys(s);
		return this;
	}

	// enter password
	@FindBy(xpath = "//input[@data-test='signin-password-text-input']")
	WebElement password;

	public SearchResult passwordEnter(String p) {
		password.sendKeys(p);
		return this;
	}

	// click submit
	@FindBy(xpath = "//button[@data-test='signin-submit-button']")
	WebElement sub;

	public SearchResult submitclick() {
		sub.click();
		return this;
	}

	public WebDriver getDriver() {
		return driver;
	}

}
