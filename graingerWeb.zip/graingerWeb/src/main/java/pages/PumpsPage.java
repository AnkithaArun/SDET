package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.DriverUtils;

public class PumpsPage {

	private WebDriver driver;
	
	@FindBy(xpath = "//a[@href='#pumps']")
	private WebElement jumppump;
	
	@FindBy(xpath = "//div[@class='categories'][2]//li[7]")
	private WebElement drumpumps;
	
	@FindBy(xpath = "//div[@id='category-container']//li[8]")
	private WebElement electricpump;
	
	@FindBy(xpath="//section[@id='74054-content']//li[10]")
	private WebElement chromic;
	
	@FindBy(xpath = "//div[@id='stack-42458-stack-4']//tr[@data-testid='table-42458-1-row-1']//td[1]")
	private WebElement carbon;
	
	@FindBy(id="input-quantity-1DLR5-1")
	private WebElement quantity;
	
	@FindBy(xpath = "//form[@data-testid='add-to-cart-form-1DLR5']//button[@type='submit']")
	private WebElement addtocart;
	
	public PumpsPage(WebDriver driver) {
		this.driver=driver;
	}
	
	
	public PumpsPage clickjumpPump() {
		jumppump.click();
		return this;
	}
	
	public PumpsPage clickDrumPump() {
		drumpumps.click();
		return this;
	}
	
	public PumpsPage clickElectricDrumPump() {
		electricpump.click();
		return this;
	}
	
	public PumpsPage clickChromic() {
		chromic.click();
		return this;
	}
	
	public PumpsPage clickCarbon() {
		DriverUtils.scrollDown(500,driver);
		carbon.click();
		return this;
	}
	
	public PumpsPage typeQuantity(String text) {
		DriverUtils.clearAndType(quantity, text);
		
		return this;
	}
	
	public PumpsPage clickAddtoCart() {
		addtocart.click();
		return this;
	}
	
	public WebDriver rerturnDriver() {
		return driver;
	}

}
