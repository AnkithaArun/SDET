package pages;

import java.time.Duration;

import javax.print.DocFlavor.READER;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class RegistrationPage {

	public static final String title="Registration";
	
	private WebDriver driver;
	
	@FindBy(id="first_name")
	private WebElement firstName;
	
	@FindBy(id = "account_type")
	private WebElement accounttype;
	
	@FindBy(id="last_name")
	private WebElement lastName;
	
	@FindBy(id="email_address")
	private WebElement email;
	
	@FindBy(id="confirm-email-address")
	private WebElement confirmmail;
	
	@FindBy(className = "Checkbox_icon__P5Xrd")
	private WebElement check;
	
	@FindBy(id="country_code")
	private WebElement countrycode;
	
	@FindBy(id="phone_number")
	private WebElement phone;
	
	@FindBy(xpath="//button[@data-testid='account-information-form-button']")
	private WebElement submit;
	
	@FindBy(id="street_address")
	private WebElement street;
	
	@FindBy(id="suite_address")
	private WebElement suitadd;
	
	@FindBy(id="zipcode")
	private WebElement zipcode;
	
	@FindBy(id="city")
	private WebElement city;
	
	@FindBy(id="region")
	private WebElement state;
	
	@FindBy(xpath = "//button[@data-testid='address-information-form-button']")
	private WebElement submit2;
	
	@FindBy(xpath = "//div[@class='zieGq jJHjg']//button[1]")
	private WebElement anyway;
	
	@FindBy(id = "create_password")
	private WebElement password;
	
	@FindBy(id = "confirm_password")
	private WebElement confirmpassword;
	
	@FindBy(xpath = "//button[@data-testid='account-security-form-button']")
	private WebElement submit3;
	
	
	public RegistrationPage(WebDriver driver) {
		this.driver=driver;
	}
	
	public RegistrationPage typeFirstname(String firstname) {
		firstName.sendKeys(firstname);
		return this;
	}
	
	public RegistrationPage selectAccountType(String text) {
		
		DriverUtils.dropDownHandling(accounttype, text);
		return this;
		
	}
	
	public RegistrationPage typeLastname(String lastname) {
		lastName.sendKeys(lastname);
		return this;
	}
	
	public RegistrationPage typeEmail(String mail){
		email.sendKeys(mail);
		return this;
		
	}
	
	public RegistrationPage typeconfirmEmail(String mail){
		confirmmail.sendKeys(mail);
		return this;
		
	}
	
	public RegistrationPage uncheckCheckbox() {
		check.click();
		return this;
	}
	
	public RegistrationPage countryCodeSelect(String text) {
		DriverUtils.dropDownHandling(countrycode, text);
		return this;
	}
	
	public RegistrationPage typePhone(String text){
		phone.sendKeys(text);
		return this;
		
	}
	
	public RegistrationPage clickSubmit() {
		submit.click();
		return this;
	}
	
	public RegistrationPage typestreet(String text){
		street.sendKeys(text);
		return this;
	}
	
	
	public RegistrationPage typesuitadd(String text){
		suitadd.sendKeys(text);
		return this;
	}
	
	public RegistrationPage typezipcode(String text){
		zipcode.sendKeys(text);
		return this;
	}
	
	public RegistrationPage typecity(String text){
		city.sendKeys(text);
		return this;
	}
	
	public RegistrationPage typestate(String text){
		DriverUtils.dropDownHandling(state, text);
		return this;
	}
	
	public RegistrationPage clickSubmit2() {
		submit2.click();
		return this;
	}
	
	public RegistrationPage clickanyway() {
		anyway.click();
		return this;
		
	}
	
	public RegistrationPage typepassword(String text){
		password.sendKeys(text);
		return this;
	}
	
	public RegistrationPage typeconfirmpassword(String text){
		confirmpassword.sendKeys(text);
		return this;
	}
	
	public DashBoardPage clickSubmit3() {
		submit3.click();
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Registration"));
		return PageFactory.initElements(driver, DashBoardPage.class);

	}
	
	public String getCurrenturl() {
		return driver.getCurrentUrl();
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	
	
}
