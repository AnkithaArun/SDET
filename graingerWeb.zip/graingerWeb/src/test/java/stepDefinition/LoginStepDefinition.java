package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import base.BaseTest;
import base.DriverUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ShowHomePage;
import pages.SignInPage;

public class LoginStepDefinition extends BaseTest{
	
	public  WebDriver driver;
	public ShowHomePage homepage;
	public String title;
	public String forgotuserid;
	public SignInPage b;
	
	
	
	@Given("the user navigates to the website")
	public void the_user_navigates_to_the_website() {
	    // Write code here that turns the phrase above into concrete actions

		driver=setup1();
		homepage = goToHomePage();
	}

	@When("the user goes to the Sign In page")
	public void the_user_goes_to_the_sign_in_page() {
	    // Write code here that turns the phrase above into concrete actions
	    homepage.clickSignIn();
	}

	@Then("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
	    // Write code here that turns the phrase above into concrete actions
		SignInPage user = new SignInPage(driver);
		title = user.getPageTitle();
		System.out.println(title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
	    // Write code here that turns the phrase above into concrete actions
		SignInPage user = new SignInPage(driver);
		title = user.getPageTitle();
		Assert.assertEquals(title, string);	
		}

	@Then("{string} link should be displayed")
	public void link_should_be_displayed(String string) {
	    // Write code here that turns the phrase above into concrete actions
		SignInPage b = homepage.clickSignIn();
		String text=b.getForgotUser();
		Assert.assertEquals(text, string);
	}

//	@When("enters their E-Mail Address as {string}")
//	public void enters_their_e_mail_address_as(String string) {
//	    // Write code here that turns the phrase above into concrete actions
//		DriverUtils.delay(3000);
//
//		SignInPage b = homepage.clickSignIn();
//		
//		b.typeUserId(string);
//	}
//
//	@When("enters their Password as {string}")
//	public void enters_their_password_as(String string) {
//	    // Write code here that turns the phrase above into concrete actions
//		DriverUtils.delay(3000);
//
//		
//		b.typePasswordId(string);
//	}
//
//	@When("clicks on the {string} button")
//	public void clicks_on_the_button(String string) {
//	    // Write code here that turns the phrase above into concrete actions
//		DriverUtils.delay(3000);
//
//		
//		b.clickSubmit();
//	}

}
