//specifies the package name for the Java class.
package com.Grainger;

// various imports necessary for the functionality of the code, such as Selenium WebDriver, TestNG annotations
import java.time.Duration;
import java.util.Properties;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.CareerPage;
import pages.DashBoardPage;
import pages.PumpsPage;
import pages.RegistrationPage;
import pages.SearchResult;
import pages.ShowHomePage;
import pages.SignInPage;
import pages.bulkorder;
import utils.ExcelUtils;
import utils.FileIO;

//registers a TestNG listener (SampleListener) to listen to the test events.
@Listeners(utils.SampleListener.class)
// defines a new Java class named GraingerRegTest, extending BaseTest, indicating it's a test class.
public class GraingerRegTest extends BaseTest {

	//declares a variable SERV_PROP_FILE of type Properties and initializes it using a method from FileIO.
	public Properties SERV_PROP_FILE = FileIO.initProperties();

	String[][] data;		//declares a 2D array data.

	//retrieves data from an Excel sheet using the ExcelUtils class.
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = ExcelUtils.testdata();
		return data;
	}

//	@Test(priority = 0)
//	public void RegisterTest() {
//		ShowHomePage homepage = goToHomePage();
//		RegistrationPage registration = homepage.clickRegistrationlink();
//		String expectedurl = "https://www.grainger.com/content/user_registration";
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(expectedurl.equalsIgnoreCase(registration.getCurrenturl())).isTrue();
//		});
//		registration.selectAccountType("Register and create a new business account");
//		registration.typeFirstname("shameems");
//		registration.typeLastname("muhd");
//		registration.typeEmail("sam1234@gmail.com");
//		registration.typeconfirmEmail("sam1234@gmail.com");
//		registration.uncheckCheckbox();
//		registration.countryCodeSelect("India - 91");
//		registration.typePhone("6538912235");
//		SoftAssertions.assertSoftly(softAssertion -> {
//			softAssertion.assertThat(DriverUtils.isElementPresent(registration.getDriver(),
//					By.xpath("//button[@data-testid='account-information-form-button']"))).isTrue();
//		});
//		registration.clickSubmit();
//		DriverUtils.delay(8000);
//
//		registration.typestreet("samma");
//		registration.typesuitadd("suhdhu");
//		registration.typezipcode("76537");
//		registration.typecity("kanan");
//		registration.typestate("Arizona");
//		registration.clickSubmit2();
//		DriverUtils.delay(8000);
//		registration.clickanyway();
//		registration.typepassword("sams#1234");
//		registration.typeconfirmpassword("sams#1234");
//		SoftAssertions.assertSoftly(softAssertion -> {
//			softAssertion.assertThat(DriverUtils.isElementPresent(registration.getDriver(),
//					By.xpath("//button[@data-testid='account-security-form-button']"))).isTrue();
//		});
//		DashBoardPage dash = registration.clickSubmit3();
//		DriverUtils.delay(3000);
//		String title = dash.getName();
//		Assert.assertEquals("Continue", title);
//
//	}

	// This method represents the test for registration functionality.
	@Test(priority = 0, dataProvider = "testData")
	public void registerTest(String accountype, String fistname, String lastname, String email, String cnfrmmail,
			String code, String phone, String street, String suit, String zipcode, String city, String state,
			String password, String confirmpaswd) {
		// Initialize the ShowHomePage instance and navigate to the registration page.
		ShowHomePage homepage = goToHomePage();
		RegistrationPage registration = homepage.clickRegistrationlink();
		
		// Expected URL for registration page.
		String expectedurl = "https://www.grainger.com/content/user_registration";
		
		// Check if the current URL matches the expected URL.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedurl.equalsIgnoreCase(registration.getCurrenturl())).isTrue();
		});
		
		 // Fill in registration details.
		registration.selectAccountType(accountype);
		registration.typeFirstname(fistname);
		registration.typeLastname(lastname);
		registration.typeEmail(email);
		registration.typeconfirmEmail(cnfrmmail);
		registration.uncheckCheckbox();
		registration.countryCodeSelect(code);
		registration.typePhone(phone);
		
		// Check if the account-information form button is present.
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isElementPresent(registration.getDriver(),
					By.xpath("//button[@data-testid='account-information-form-button']"))).isTrue();
		});
		
		// Delay for 5 seconds.
		DriverUtils.delay(5000);
		
		// Click the submit button for account information.
		registration.clickSubmit();
		DriverUtils.delay(8000);

		// Fill in address and other details.
		registration.typestreet(street);
		registration.typesuitadd(suit);
		registration.typezipcode(zipcode);
		registration.typecity(city);
		registration.typestate(state);
		registration.clickSubmit2();
		
		// Check if the account-security form button is present.
		DriverUtils.delay(8000);
		registration.clickanyway();
		registration.typepassword(password);
		registration.typeconfirmpassword(confirmpaswd);
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isElementPresent(registration.getDriver(),
					By.xpath("//button[@data-testid='account-security-form-button']"))).isTrue();
		});
		
		// Click the submit button for account security.
		DashBoardPage dash = registration.clickSubmit3();
		DriverUtils.delay(3000);
		
		// Check the title after registration.
		String title = dash.getName();
		Assert.assertEquals("Continue", title);

	}

	// This method represents the test for registration failure.
	@Test(priority = 1)
	public void registerFailTest() {
		
		 // Initialize the ShowHomePage instance and navigate to the registration page.
		ShowHomePage homepage = goToHomePage();
		RegistrationPage registration = homepage.clickRegistrationlink();
		
		// Expected URL for registration page.
		String expectedurl = "https://www.grainger.com/content/user_registration";
		
		// Check if the current URL matches the expected URL.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedurl.equalsIgnoreCase(registration.getCurrenturl())).isTrue();
		});
		
		// Fill in registration details for a failed registration scenario.
		registration.selectAccountType("Register and create a new business account");
		registration.typeFirstname("shameems");
		registration.typeLastname("muhd");
		registration.typeEmail("sam1234@gmail.com");
		registration.typeconfirmEmail("sam124@gmail.com");
		registration.uncheckCheckbox();
		registration.countryCodeSelect("India - 91");
		registration.typePhone("6538912235");
		
		// Check if the account-information form button is present.
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isElementPresent(registration.getDriver(),
					By.xpath("//button[@data-testid='account-information-form-button']"))).isTrue();
		});
		
		// Click the submit button for account information.
		registration.clickSubmit();
		// Check if a specific element indicating a registration failure is displayed.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(homepage.getDriver()
					.findElement(By.xpath("//span[@class='N5ad3 KjtQT epMie ggklJ']")).isDisplayed());
		});

	}

	@Test(priority = 2)
	public void registerEmptyTest() {
		ShowHomePage homepage = goToHomePage();
		RegistrationPage registration = homepage.clickRegistrationlink();
		String expectedurl = "https://www.grainger.com/content/user_registration";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedurl.equalsIgnoreCase(registration.getCurrenturl())).isTrue();
		});
		registration.selectAccountType("Register and create a new business account");
		registration.typeFirstname("shameems");
		registration.typeLastname("muhd");
		registration.uncheckCheckbox();
		registration.countryCodeSelect("India - 91");
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isElementPresent(registration.getDriver(),
					By.xpath("//button[@data-testid='account-information-form-button']"))).isTrue();
		});
		registration.clickSubmit();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					homepage.getDriver().findElement(By.xpath("//div[@id=\"email_address-helper-text\"]/div/span[2]"))
							.getText().equalsIgnoreCase("Required"));
		});

	}

	@Test(priority = 3)
	public void pumpsTest() {
		ShowHomePage homepage = goToHomePage();
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isTextPresent(homepage.getDriver(), "Plumbing & Pumps")).isTrue();
		});
		PumpsPage pumps = homepage.clickPumpslink();
		DriverUtils.delay(3000);
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion
					.assertThat(DriverUtils.isElementPresent(homepage.getDriver(), By.xpath("//a[@href='#pumps']")))
					.isTrue();
		});

		pumps.clickjumpPump();
		DriverUtils.delay(3000);
		pumps.clickDrumPump();
		DriverUtils.delay(3000);
		pumps.clickElectricDrumPump();
		DriverUtils.delay(2000);
		pumps.clickChromic();
		DriverUtils.delay(10000);

		pumps.clickCarbon();
		DriverUtils.delay(3000);
		pumps.typeQuantity("2");
		pumps.clickAddtoCart();
		DriverUtils.delay(3000);
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(homepage.getDriver()
					.findElement(By.xpath("//a[@data-test='signin-register-button']")).isDisplayed()).isTrue();

		});

	}

	@Test(priority = 4)
	public void careerTest() throws InterruptedException {
		ShowHomePage homepage = goToHomePage();
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isTextPresent(homepage.getDriver(), "Careers")).isTrue();
		});
		DriverUtils.delay(5000);
		CareerPage career = homepage.clickCareerlink();
		String actualurl = career.getBaseURL();
		String expectedurl = "https://jobs.grainger.com/";
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(actualurl.equalsIgnoreCase(expectedurl)).isTrue();

		});

		career.typeKeyword("Manager");
		career.typeCity("Austin");

		career.clickSearch();
		career.clickSalesRep();
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion
					.assertThat(homepage.getDriver().findElement(By.xpath("//button[@class='btn savesearch-link']"))
							.getText().equalsIgnoreCase(" Create Alert"));

		});

		career.clickApply();
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(homepage.getDriver().findElement(By.tagName("h1")).isDisplayed()).isTrue();

		});
	}
	
	@Test(priority = 5)
	public void clickBulk() {
		
		 // Initialize the ShowHomePage instance and navigate to the homepage
		ShowHomePage homepage = goToHomePage();
		
		  // Add a delay of 3000 milliseconds (3 seconds)
		DriverUtils.delay(3000);
		
		// Initialize a bulkorder instance by clicking on the bulk order link.
		bulkorder b = homepage.bulorderClick();
		
		// Soft assertion to check if the bulk order link is displayed.
		SoftAssertions.assertSoftly(softAssertion -> {

			softAssertion.assertThat(homepage.getDriver()
					.findElement(By.xpath("//a[@class='gcom__header-bulk-order-link']")).isDisplayed()).isTrue();

		});

		// Soft assertion to check if the bulk order form title is displayed.
		SoftAssertions.assertSoftly(softAssertion -> {

			softAssertion.assertThat(homepage.getDriver()
					.findElement(By.xpath("(//h2[@class='bulk-order-form__title'])[1]")).isDisplayed()).isTrue();

		});
		
		SoftAssertions.assertSoftly(softAssertion -> {

			softAssertion.assertThat(homepage.getDriver()
					.findElement(By.xpath("//button[@class='button  bulk-order-form__content-add-row']")).isDisplayed()).isTrue();

		});

		// Select an item for bulk ordering.
		b.item("38EG41");
		// Add a delay of 5000 milliseconds (5 seconds).
		DriverUtils.delay(5000);
		
		// Choose a quantity for the selected item.
		b.quantity();
		// Add a delay of 5000 milliseconds (5 seconds).
		DriverUtils.delay(5000);
		
		// Select another item for bulk ordering.
		b.item1("39CR70");
		// Add a delay of 5000 milliseconds (5 seconds).
		DriverUtils.delay(5000);
		
		// Choose a quantity for the second selected item.
		b.quantity1();
		// Add a delay of 5000 milliseconds (5 seconds).
		DriverUtils.delay(5000);
		
		// Click on the cart to proceed with bulk order.
		b.cartclk();
		// Add a delay of 5000 milliseconds (5 seconds).
		DriverUtils.delay(5000);
		
		// Soft assertion to check if the heading span is displayed.
		SoftAssertions.assertSoftly(softAssertion -> {

			softAssertion
					.assertThat(homepage.getDriver().findElement(By.xpath("//span[@slot='heading']")).isDisplayed())
					.isTrue();

		});
		
		DriverUtils.delay(2000);
		b.nameEnter("sams121@gmail.com");
		DriverUtils.delay(2000);
		b.passwordEnter("sams#1212");
		DriverUtils.delay(2000);
		b.submitclick();

	}

	@Test(priority = 6)
	public void searchTest() throws InterruptedException {
		ShowHomePage homepage = goToHomePage();
		homepage.enterserch("bulb");
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(homepage.getDriver()
					.findElement(By.xpath("//input[@class='gcom__typeahead-query-field']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(
					DriverUtils.isElementPresent(homepage.getDriver(), By.className("gcom__typeahead-submit-button")))
					.isTrue();
		});
		SearchResult sr = homepage.enterBtn();
		// DriverUtils.delay(2000);
		sr.ledclk();
		DriverUtils.delay(4000);
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(
					homepage.getDriver().findElement(By.xpath("//td[@data-testid='table-36704-row-1-cell-3']//div[@class='EJzsjT']"))
							.getText().equalsIgnoreCase("60 W"));
		});
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isTextPresent(sr.getDriver(), "LED")).isTrue();
		});
		sr.ledclk();
		DriverUtils.delay(2000);
		SoftAssertions.assertSoftly(softAssertion -> {
			softAssertion.assertThat(DriverUtils.isTextPresent(sr.getDriver(), "Add to Cart")).isTrue();
		});
		sr.cartclick();
		DriverUtils.delay(2000);
		sr.nameEnter("sams121@gmail.com");
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(homepage.getDriver()
					.findElement(By.xpath("//input[@data-test='signin-username-text-input']")).isDisplayed());

		});
		DriverUtils.delay(2000);
		sr.passwordEnter("sams#1212");
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(homepage.getDriver()
					.findElement(By.xpath("//input[@data-test='signin-password-text-input']")).isDisplayed());

		});
		DriverUtils.delay(2000);
		sr.submitclick();

	}
	
	// This method represents the test for clicking on bulk order functionality.
	

//	@Test(priority = 6)
//	public void clickDEmo() {
//		ShowHomePage homepage = goToHomePage();
//		SignInPage b = homepage.clickSignIn();
//		String link=b.getForgotUser();
//		System.out.println(link);
//		
//		
//	}

}
