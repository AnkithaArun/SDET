package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class MessagesPages {
	private static WebDriver driver;
	WebDriverWait wait;
	
	public MessagesPages(AndroidDriver driver) {
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Got it\")")
	private WebElement gotit;
	
	@AndroidFindBy(accessibility = "Start chat")
	private WebElement startchat;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Type a name, phone number, or email\")")
	private WebElement enternum;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Text message\")")
	private WebElement entermsg;
	
	@AndroidFindBy(accessibility  = "Send SMS")
	private WebElement sndsms;

	
	public void gotItButton() {
		gotit.click();
	}
	
	public void startChat() {
		startchat.click();	
	}
	
	public void enterNumber(String num) {
		enternum.sendKeys(num);
	}
	public void sendMessage(String msg) {
		entermsg.sendKeys(msg);
	}
	public void sendingMsg() {
		sndsms.click();
	}
	
}
