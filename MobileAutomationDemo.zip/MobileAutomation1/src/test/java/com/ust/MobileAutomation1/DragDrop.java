package com.ust.MobileAutomation1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

public class DragDrop extends BaseTest{
	
	@Test
	public void clickview() throws InterruptedException {
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		//driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"WebView\"));"));
		//scrolltoendAction();
		driver.findElement(AppiumBy.accessibilityId("Drag and Drop")).click();
		WebElement source =driver.findElement(By.id("io.appium.android.apis:id/drag_dot_1"));
		((JavascriptExecutor)driver).executeScript("mobile: dragGesture", ImmutableMap.of("elementId",((RemoteWebElement)source).getId(),
				"endX",641,
				"endY",653));
		Thread.sleep(3000);
		String expected="Dropped!";
		String actual=driver.findElement(By.id("io.appium.android.apis:id/drag_result_text")).getText();
		Assert.assertEquals(actual, expected);	}

}
