package com.ust.MobileAutomation1;

import java.time.Duration;

import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import base.BaseChrome;
import page.ChromePage;


public class ChromeTest extends BaseChrome {
	
	@Test
	public void chrome() {
	ChromePage cp = new ChromePage(driver);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	cp.accAndCont();
	cp.noThanksClick();
	cp.noThanks2Click();
	cp.searchText("mycontactform.com");
	driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
	}

}
