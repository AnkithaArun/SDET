package com.ust.MobileAutomation1;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class CheckBox extends BaseTest{
	
	@Test
	public void wifiSettingsTest() {
		driver.findElement(AppiumBy.accessibilityId("Preference")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"3. Preference dependencies\"]")).click();
		driver.findElement(AppiumBy.className("android.widget.CheckBox")).click();
		
	}

}
