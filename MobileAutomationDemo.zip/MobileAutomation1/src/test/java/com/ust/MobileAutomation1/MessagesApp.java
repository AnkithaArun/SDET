package com.ust.MobileAutomation1;

import java.net.MalformedURLException;

import java.time.Duration;

import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import base.Base;
import io.appium.java_client.android.AndroidDriver;
import page.MessagesPages;

public class MessagesApp extends Base{
	
	@Test
	public void messages() throws MalformedURLException {
		MessagesPages mp = new MessagesPages(driver);
//		DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
//		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
//		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Ankitha_Name");
//		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.google.android.apps.messaging");
//		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.google.android.apps.messaging.ui.ConversationListActivity");
//		AndroidDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"),capabilities);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		mp.gotItButton();
		mp.startChat();
		mp.enterNumber("9539616565");
		driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
		mp.sendMessage("Hello");
		mp.sendingMsg();
//		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Got it\")")).click();
//		driver.findElement(AppiumBy.accessibilityId("Start chat")).click();
//		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Type a name, phone number, or email\")")).sendKeys("9539616565");
//		driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
//		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Text message\")")).sendKeys("Hello");
//		driver.findElement(AppiumBy.accessibilityId("Send SMS")).click();
	}

}
