package com.ust.MobileAutomation1;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class BaseTest {
	public AndroidDriver driver;
	
	@BeforeTest
	public void setUp() throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("Ankitha_Name");
		options.setApp("C:\\Eclipse Mobile Automation\\MobileAutomation1\\src\\test\\java\\reources\\ApiDemos-debug.apk");
		options.setPlatformName("Android");
		driver = new AndroidDriver(new URL(" http://10.11.74.234:4723/"),options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	

}
