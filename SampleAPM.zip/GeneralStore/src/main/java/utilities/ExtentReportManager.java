package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.android.AndroidDriver;

public class ExtentReportManager {
	
	public ExtentReportManager(AndroidDriver driver) {
		super();
		}
		public static ExtentTest logger;
		public static String timestamp = DateUtils.getTimeStamp();
		public static ExtentReports extent;
		public static ExtentSparkReporter spark;
		/***************************
		 * Getting report instance for extent report
		 **************/
		public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + timestamp + ".html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Ankitha");
		spark.config().setDocumentTitle("ContactApp");
		spark.config().setReportName("new result");
		spark.config().setTheme(Theme.DARK);
		return extent;
		}

}
