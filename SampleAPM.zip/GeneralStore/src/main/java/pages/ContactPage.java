package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class ContactPage extends AndroidActions {

	AndroidDriver driver;
	
	public ContactPage(AndroidDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(id ="android:id/button2")
	private WebElement skip;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Allow\")")
	private WebElement allow;
	
	@AndroidFindBy(accessibility = "Create contact")
	private WebElement createconatct;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"First name\")")
	private WebElement fname;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Last name\")")
	private WebElement lname;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Company\")")
	private WebElement cmpname;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Phone\")")
	private WebElement phone;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Email\")")
	private WebElement email;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Save\")")
	private WebElement save;
	
	@AndroidFindBy(id ="com.google.android.contacts:id/large_title")
	private WebElement fullname;
	
	@AndroidFindBy(uiAutomator ="new UiSelector().text(\"Text\")")
	private WebElement text;
	
	@AndroidFindBy(id ="com.google.android.apps.messaging:id/compose_message_text")
	private WebElement txtmsg;
	
	@AndroidFindBy(accessibility = "Send SMS")
	private WebElement snd;
	
	public void clickSkip() {
		skip.click();
	}
	
	public void clickAllow() {
		allow.click();
	}
	
	public void clickCreateContact() {
		createconatct.click();	
	}
	
	public void enterFirstName(String firstname) {
		fname.sendKeys(firstname);
	}
	
	public boolean isFNameFieldPresent() {
		return fname.isDisplayed();
	}
	
	public void enterLastName(String lastname) {
		lname.sendKeys(lastname);
	}
	
	public boolean isLNameFieldPresent() {
		return lname.isDisplayed();
	}
	
	public void enterCompanyName(String company) {
		cmpname.sendKeys(company);
	}
	
	public void enterPhoneNumber(String ph) {
		phone.sendKeys(ph);
	}
	
	public boolean isPhoneFieldPresent() {
		return phone.isDisplayed();
	}
	public void enterEmail(String mail) {
		email.sendKeys(mail);
	}
	
	public void clickSave() {
		save.click();
	}
	
	public String readFullName() {
		return fullname.getText();
	}
	public void clickText() {
		text.click();
	}
	public void enterTextMsg(String msg) {
		txtmsg.sendKeys(msg);
	}
	
	public boolean isSendButtonPresent() {
		return snd.isDisplayed();
	}
	public void clickSend() {
		snd.click();
	}

}
