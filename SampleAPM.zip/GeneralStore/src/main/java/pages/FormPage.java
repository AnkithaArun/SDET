package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class FormPage extends AndroidActions {
	
	AndroidDriver driver;

	public FormPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/spinnerCountry")
	WebElement country;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/nameField")
	WebElement name;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/radioFemale")
	WebElement female;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/radioMale")
	WebElement male;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/btnLetsShop")
	WebElement shopbtn;
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView[2]")
	WebElement atc;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/appbar_btn_cart")
	WebElement cart;
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.CheckBox")
	WebElement check;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/btnProceed")
	WebElement proceed;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/productPrice")
	WebElement productprice;
	
	public void scrollCountry(String cname) {
		country.click();
		scrollToTextAndClick(cname);
	}
	
	public void enterName(String nm) {
		name.sendKeys(nm);	
	}
	
	public void selectGender(String gender) {
		if(gender.contains("Female"))
			female.click();
		else
			male.click();
	}
	
	public void clickShop() {
		shopbtn.click();
	}
	 
	public void scrollToItem(String item) {
		scrollToText(item);
	}
	public void addToCartClick() {
		atc.click();
	}
	
	public void Cart() {
		cart.click();
	}
	
	public void Checkbox() {
		check.click();
	}
	
	public void Proceed() {
		proceed.click();
	}
	
	public String productPrice() {
		return productprice.getText();
	}

}
