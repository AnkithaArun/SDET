package com.ust.GeneralStore;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTestGeneralStore;
import pages.FormPage;

public class FormTest extends BaseTestGeneralStore{
	
	@DataProvider(name = "getData")

	public Object[][] getData() throws IOException {
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "/src/test/java/testdata/data.json");
		Object[][] testData = new Object[data.size()][2];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("name");
			testData[i][1] = row.get("country");
			}
		return testData;
		}
	
	@Test(dataProvider = "getData")
	public void form(String name,String country) throws InterruptedException {
		FormPage fp = new FormPage(driver);
		Thread.sleep(1000);
		fp.scrollCountry(country);
		fp.enterName(name);
		fp.selectGender("Female");
		fp.clickShop();
		fp.scrollToItem("Air Jordan 4 Retro");
		fp.addToCartClick();
		fp.Cart();
		String expected = fp.productPrice();
		String actual ="$160.97";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
		});
		fp.Checkbox();
		//fp.Proceed();
	}

	
}
