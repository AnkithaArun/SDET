package com.ust.GeneralStore;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTestContacts;
import pages.ContactPage;
@Listeners(utilities.SampleListener.class)
public class ContactTest extends BaseTestContacts {
	@DataProvider(name = "getData")

	public Object[][] getData() throws IOException {
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "/src/test/java/testdata/contact.json");
		Object[][] testData = new Object[data.size()][6];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("Firstname");
			testData[i][1] = row.get("Lastname");
			testData[i][2] = row.get("Companyname");
			testData[i][3] = row.get("Phone");
			testData[i][4] = row.get("Email");
			testData[i][5] = row.get("Message");
			}
		return testData;
		}
	@Test(dataProvider ="getData")
	public void contact(String fname,String lname,String cmp,String phone,String mail,String msg) {
		ContactPage cp = new ContactPage(driver);
		cp.clickSkip();
		cp.clickAllow();
		cp.clickCreateContact();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(cp.isFNameFieldPresent()).isTrue();
		});
		cp.enterFirstName(fname);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(cp.isLNameFieldPresent()).isTrue();
		});
		cp.enterLastName(lname);
		cp.enterCompanyName(cmp);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(cp.isPhoneFieldPresent()).isTrue();
		});
		cp.enterPhoneNumber(phone);
		cp.enterEmail(mail);
		cp.clickSave();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat((fname+" "+lname).equalsIgnoreCase(cp.readFullName())).isTrue();
		});
		cp.clickText();
		cp.enterTextMsg(msg);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(cp.isSendButtonPresent()).isTrue();
		});
		cp.clickSend();
		
	}

}
