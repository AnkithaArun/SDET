package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class BrowserConfig {
	static WebDriver driver;
	public static WebDriver getBrowser() {
	driver=new EdgeDriver();
	driver.get("https://casekaro.com/");
	driver.manage().window().maximize();
	return driver;
	}
}




