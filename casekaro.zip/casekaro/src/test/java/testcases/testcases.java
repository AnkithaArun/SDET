package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.AddCart;
import POM.createLogin;
import Utility.ExcelUtilities;
import Utility.excelUtility;

@Listeners(Utility.SampleListener.class)
public class testcases extends BaseUI {

	WebDriver driver;
	createLogin login;
	AddCart cart;
	String[][] data;
	
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		openBrowser("appURL");
	}
	@DataProvider(name = "testdata")
	public Object[][] testdata(){
		data= excelUtility.testdata();
		return data;
	}
	
	@DataProvider(name = "testData")
	public Object[][] testData(){
		data= ExcelUtilities.testData();
		return data;
	}
	
	@Test(priority=0)
	public void accoutCase() {
		createLogin login=new createLogin(driver);
		String a=driver.getCurrentUrl();
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://casekaro.com/"));
		 });
		 
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//a[@class='site-header__logo-link']")).isDisplayed());});
		
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//p[text()='FREE Shipping above ₹299']")).isDisplayed());});
		
		login.loginacc();
		
	}
	
	@Test(priority=1,dataProvider = "testdata")
	public void accreg(String first,String last,String email,String pass) {
		createLogin login=new createLogin(driver);
		
		login.createacc();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Create Account']")).isDisplayed());});
		login.FirstName(first);
		login.LastName(last);
		login.Email(email);
		login.Password(pass);
		
		login.createbutton();
		login.checkbox();
		login.checkSubmit();
		
	}
	
	@Test(priority=2,dataProvider = "testData")
	public void accLogin(String email,String pass) {
		createLogin login=new createLogin(driver);
		login.loginnext();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Login']")).isDisplayed());});
		
		login.loginemail(email);
		login.loginpassword(pass);
		login.loginSubmit();
		login.checkbox();
		login.checkSubmit();
	
	}
	

	@Test(priority=3)
	public void CartAdd() {
		AddCart cart=new AddCart(driver);
		cart.popDrop();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[@role='text']")).isDisplayed());});
		
		cart.popfeature();
		cart.FeatureSelect();
		cart.ProductClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Abstract Printed Pop Holder']")).isDisplayed());});
		
		cart.productCart();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Your cart']")).isDisplayed());});
		
		cart.ContinueShop();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[@role='text']")).isDisplayed());});
		
		cart.CaseHome();
		
		
	}
	
}