package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import Base.BrowserConfig;
import POM.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Loginsteps {
	
	private static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public LoginPage login=new LoginPage(driver);
	

@Given("user is on login page")
public void user_is_on_login_page() {
    // Write code here that turns the phrase above into concrete actions
	driver.get("https://casekaro.com/");
}

@When("user gets the title of page")
public void user_gets_the_title_of_page() {
    // Write code here that turns the phrase above into concrete actions

	title=login.getLoginPageTitle();
	System.out.println(title);
}

@Then("page title be {string}")
public void page_title_be(String titlename) {
	title=login.getLoginPageTitle();
	Assert.assertEquals("Buy Mobile Back Covers and Cases at just Rs.99 – Casekaro",titlename);
}


@When("user click the signin button")
public void user_click_the_signin_button() {
  login.loginPage();
}


@When("user enters username {string}")
public void user_enters_username(String email) {
   login.sendemail(email);
}

@When("user enters password {string}")
public void user_enters_password(String password) {
   login.sendPassword(password);
}

@When("user clicks on Login button")
public void user_clicks_on_login_button() {
	login.clickSubmit();
}


@Then("page title should be {string}")
public void page_title_should_be(String string) {
	title=login.getLoginPageTitle();
	Assert.assertEquals(title, string);
}

}
