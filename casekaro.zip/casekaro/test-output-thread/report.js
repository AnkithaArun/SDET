$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"e447a24e-749b-49f1-a3e0-20e0532a8a2a","feature":"Login page feature","scenario":"Login page title","start":1692875071159,"group":1,"content":"","tags":"","end":1692875085006,"className":"passed"},{"id":"f4c3c7ee-b826-4337-8205-322d6cc54681","feature":"Login page feature","scenario":"Login with correct credentials","start":1692875085013,"group":1,"content":"","tags":"","end":1692875100380,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});