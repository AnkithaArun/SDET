package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.CatPage;

public class CatTest extends BaseUI {

	WebDriver driver;

	@BeforeTest

	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}

	@Test(priority = 1)

	public void checkCat() {

		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("nav--Cats")).getText().contains("cat"));
		});
		c.performMouseOver();
	}

	@Test(priority = 2)

	public void DropdownTest() throws InterruptedException {
		CatPage c = new CatPage(driver);
		c.dropDown();
		Boolean drop = c.dropDown();
		Assert.assertTrue(drop);
		Thread.sleep(3000);
		c.performClick();
	}

	@Test(priority = 3)

	public void checkEntry() throws InterruptedException {

		CatPage c = new CatPage(driver);
		String expectedURL = "https://supertails.com/collections/cat-grooming-products";
		driver.get(expectedURL);
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(actualURL, expectedURL, "URLs do match");
		if (actualURL.equals(expectedURL)) {
			Thread.sleep(3000);
			c.performBrandClick();
			Thread.sleep(3000);
			c.PerformBioClick();
			Thread.sleep(3000);
			System.out.println("Test Passed: The URL is as expected");
		}
	}

	@Test(priority = 4)

	public void checkBox() throws InterruptedException {
		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath(
					"//button[@class='findify-components--button findify-components-common--checkbox__item'][4]"))
					.isEnabled());
		});
		c.PerformProductClick();
		Thread.sleep(3000);
		c.performQuantityClick();
		Thread.sleep(3000);
		c.performAddToCartClick();
		Thread.sleep(3000);
		c.performCartView();
		Thread.sleep(3000);
		System.out.println("");

	}

	@Test(priority = 5)

	public void addToCart() throws InterruptedException {
		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//div[@class='cart__scrollable']")).isDisplayed());
		});
		Thread.sleep(5000);
		c.performAddToCartClick();

	}

	@Test(priority = 6)

	public void checkQuantity() {
		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver
					.findElements(By.xpath("//button[@class='js-qty__adjust js-qty__adjust--plus'][1]")).equals(2));

		});

	}

}
