package com.ust.fashion.utils;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ust.fashion.base.DriverUtils;

public class ExtentReportManager extends DriverUtils {
	public ExtentReportManager(WebDriver driver) {
		super(driver);
	}

	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	/***************************
	 * Getting report instance for extent report
	 **************/

	public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + DriverUtils.timestamp + ".html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Yadunath K");
		spark.config().setDocumentTitle("FashionDealTest");
		spark.config().setReportName("new result");
		spark.config().setTheme(Theme.DARK);

		return extent;
	}
}