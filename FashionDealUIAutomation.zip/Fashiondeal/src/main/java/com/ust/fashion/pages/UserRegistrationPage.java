package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.fashion.base.DriverUtils;

/**
 * This class represents a page object for the User Registration page of a web
 * application.
 */
public class UserRegistrationPage {
	// WebDriver and WebDriverWait for browser automation
	private WebDriver driver;
	WebDriverWait wait;

	// Constant for the expected page title
	public static final String title = "Account Login";

	/**
	 * Constructor for the UserRegistrationPage class.
	 *
	 * @param driver The WebDriver instance to use for interacting with the page.
	 */
	public UserRegistrationPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}

	// WebElement declarations using @FindBy annotations
	@FindBy(xpath = "//span[normalize-space()='Sign In']")
	private WebElement signin;
	@FindBy(xpath = "//a[@class='btn btn-primary']")
	private WebElement continuebutton;
	@FindBy(xpath = "//input[@id='input-firstname']")
	private WebElement firstname;
	@FindBy(xpath = "//input[@id='input-lastname']")
	private WebElement lastname;
	@FindBy(xpath = "//input[@id='input-email']")
	private WebElement email;
	@FindBy(xpath = "//input[@id='input-telephone']")
	private WebElement telephone;
	@FindBy(xpath = "//input[@id='input-password']")
	private WebElement password;
	@FindBy(xpath = "//input[@id='input-confirm']")
	private WebElement passwordconfirm;
	@FindBy(xpath = "//div[@class='pull-right']//input[@name='agree']")
	private WebElement checkbox;
	@FindBy(xpath = "//button[@data-loading-text='<span>Continue</span>']")
	private WebElement continuebutton2;
	@FindBy(xpath = "//div[@class='alert alert-danger alert-dismissible']")
	private WebElement erroralert;
	@FindBy(xpath = "//h1[@class='title page-title']")
	private WebElement successmsg;

	// Methods for interacting with page elements
	// ...
	public void clickContinue() {
		continuebutton.click();
	}

	public void inputFirstName(String fname) {
		firstname.sendKeys(fname);
	}

	public void inputLastName(String lname) {
		lastname.sendKeys(lname);
	}

	public void inputEmail(String emailid) {
		email.sendKeys(emailid);
	}

	public void inputTelephone(String tele) {
		telephone.sendKeys(tele);
	}

	public void inputPassword(String pass) {
		password.sendKeys(pass);
	}

	public void inputConfirmPassword(String cnfpass) {
		passwordconfirm.sendKeys(cnfpass);
	}

	public void clickCheckbox() {
		checkbox.click();
	}

	public void clickContinuebutton2() {
		continuebutton2.click();
	}

	/**
	 * Get the current URL of the web page.
	 *
	 * @return The current URL.
	 */
	public String actualURL() {
		return driver.getCurrentUrl();
	}

	/**
	 * Get the text of the error message element.
	 *
	 * @return The text of the error message.
	 */
	public String errorMsgText() {
		return DriverUtils.getText(erroralert);
	}

	/**
	 * Get the WebDriver instance associated with this page.
	 *
	 * @return The WebDriver instance.
	 */
	public WebDriver driverreturn() {
		return driver;
	}

	/**
	 * Get the text of the success message element.
	 *
	 * @return The text of the success message.
	 */
	public String successMsg() {
		return DriverUtils.getText(successmsg);
	}
}
