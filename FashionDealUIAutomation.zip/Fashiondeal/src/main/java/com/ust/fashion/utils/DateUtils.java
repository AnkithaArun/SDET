package com.ust.fashion.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

//to save the report with date, dateformat is created
public class DateUtils {
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}
}
