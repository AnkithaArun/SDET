package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.fashion.base.DriverUtils;

public class UserLoginPage {
	// WebDriver and WebDriverWait for browser automation
	private static WebDriver driver;
	WebDriverWait wait;

	// Constant for the expected page title
	public static final String title = "Account Login";

	/**
	 * Constructor for the UserLoginPage class.
	 *
	 * @param driver The WebDriver instance to use for interacting with the page.
	 */
	public UserLoginPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}

	// WebElement declarations using @FindBy annotations
	@FindBy(xpath = "//input[@id='input-email']")
	private WebElement email;
	@FindBy(xpath = "//input[@id='input-password']")
	private WebElement password;
	@FindBy(xpath = "//button[@data-loading-text='<span>Login</span>']")
	private WebElement login;
	@FindBy(xpath = "//a[@class='dropdown-toggle']//span[@class='links-text'][normalize-space()='Account']")
	private WebElement account;
	@FindBy(xpath = "//span[normalize-space()='Sign Out']")
	private WebElement signout;
	@FindBy(xpath = "//div[@id='content']//h1")
	private WebElement myaccount;
	@FindBy(xpath = "//div[@class='alert alert-danger alert-dismissible']")
	private WebElement errormessage;
	@FindBy(xpath = "//a[normalize-space()='Forgotten Password']")
	private WebElement forgot;
	@FindBy(xpath = "//a[@class='btn btn-primary']")
	 private WebElement continuebutton;

	/**
	 * Input an email into the email input field.
	 *
	 * @param iemail The email to be entered.
	 */
	public void inputEmail(String iemail) {
		email.sendKeys(iemail);
	}

	/**
	 * Input a password into the password input field.
	 *
	 * @param ipassword The password to be entered.
	 */

	public void inputPassword(String ipassword) {
		password.sendKeys(ipassword);
	}

	/**
	 * Click the login button.
	 */
	public void clickLogin() {
		login.click();
	}

	/**
	 * Perform a mouseover action on the account dropdown element.
	 */
	public void mouseoverAccount() {
		DriverUtils.mouseOver(returnDriver(), account);
	}

	/**
	 * Click the sign-out option.
	 */
	public void clickSignOut() {
		signout.click();
	}

	/**
	 * Get the error message text.
	 *
	 * @return The text of the error message.
	 */
	public String errorMessage() {
		return DriverUtils.getText(errormessage);
	}

	/**
	 * Get the text of the "My Account" section.
	 *
	 * @return The text of the "My Account" section.
	 */
	public String myAccount() {
		return myaccount.getText();
	}

	/**
	 * Get the current URL of the web page.
	 *
	 * @return The current URL.
	 */
	public String getBaseUrl() {
		return driver.getCurrentUrl();
	}

	/**
	 * Check if the "Forgotten Password" link is displayed.
	 *
	 * @return True if the link is displayed, otherwise false.
	 */
	public boolean forgotPassword() {
		return forgot.isDisplayed();
	}

	/**
	 * Get the WebDriver instance.
	 *
	 * @return The WebDriver instance.
	 */
	public static WebDriver returnDriver() {
		return driver;
	}

	/**
	 * Retrieves the title of the web page.
	 *
	 * @return The title of the web page.
	 */
	public String getLoginTitle() {
		return driver.getTitle();
	}

	/**
	 * Retrieves the text from the "forgot password" element.
	 *
	 * @return The text from the "forgot password" element.
	 */
	public String getforgotPasswordText() {
		return DriverUtils.getText(forgot);
	}

	/**
	 * Retrieves the text from the "login" button element.
	 *
	 * @return The text from the "login" button element.
	 */
	public String getLoginButtonText() {
		return DriverUtils.getText(login);
	}

}
