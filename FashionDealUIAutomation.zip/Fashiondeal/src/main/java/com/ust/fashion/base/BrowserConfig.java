package com.ust.fashion.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

/**
 * The BrowserConfig class provides methods to create and configure web browser
 * instances such as Chrome and Edge. It allows users to obtain WebDriver
 * instances with specific configurations for each browser.
 */
public class BrowserConfig {
	static WebDriver driver;

	/**
	 * Initializes and configures a Chrome WebDriver instance with specific options.
	 * The options include disabling notifications and allowing remote origins.
	 *
	 * @return A Chrome WebDriver instance.
	 */

	public static WebDriver getchromebrowser() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		return driver;
	}

	/**
	 * Initializes and configures an Edge WebDriver instance with specific options.
	 * The options include disabling notifications and allowing remote origins.
	 *
	 * @return An Edge WebDriver instance.
	 */
	public static WebDriver getedgebrowser() {
		EdgeOptions options = new EdgeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--remote-allow-origins=*");
		driver = new EdgeDriver(options);
		driver.manage().window().maximize();
		return driver;
	}

}
