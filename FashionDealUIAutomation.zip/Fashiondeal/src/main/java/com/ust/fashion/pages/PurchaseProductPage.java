package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.fashion.base.DriverUtils;

/**
 * This class represents a page object for the Purchase Product page of a web application.
 */
public class PurchaseProductPage {
	private WebDriver driver;
	WebDriverWait wait;
	
	 /**
     * Constructor for the PurchaseProductPage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	public PurchaseProductPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}
	
	 // WebElement declarations using @FindBy annotations
    // ...
	@FindBy(xpath = "//input[@value='130']")
	private WebElement weddingsaree;
	@FindBy(xpath = "//span[normalize-space()='Dusty Rose']")
	private WebElement dustyrose;
	@FindBy(xpath = "//span[normalize-space()='Pink']")
	private WebElement pink;
	@FindBy(xpath = "//select[@id='input-sort']")
	private WebElement sortby;
	@FindBy(xpath = "//a[contains(text(),'Dusty rose heavy embroidered wedding bollywood sar')]")
	private WebElement selectproduct;
	@FindBy(xpath = "//a[@id='button-cart']//span[@class='btn-text'][normalize-space()='Add to Cart']")
	private WebElement addtocartbutton;
	@FindBy(xpath = "//div[@class='notification-title']")
	private WebElement cartpopup;
	@FindBy(xpath = "//i[@class='fa fa-shopping-cart']")
	private WebElement cartmouseover;
	@FindBy(xpath = "//a[@class='btn-cart btn']")
	private WebElement viewcart;
	@FindBy(xpath = "//div[@class='stepper']//i[@class='fa fa-angle-up']")
	private WebElement addquantity;
	@FindBy(xpath = "//button[@class='btn btn-update']")
	private WebElement update;
	@FindBy(xpath = "//span[normalize-space()='Continue Shopping']")
	private WebElement continueshopping;
	@FindBy(xpath = "//body[1]/div[4]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]")
	private WebElement productcheck;
	@FindBy(xpath = "//div[@class='alert alert-success alert-dismissible']")
	private WebElement updatesuccess;
	
	 /**
     * Get the WebDriver instance associated with this page.
     *
     * @return The WebDriver instance.
     */
	public WebDriver driverreturn() {
		return driver;
	}
	
	/**
     * Get the current URL of the web page.
     *
     * @return The current URL.
     */
	public String actualURL() {
		return driver.getCurrentUrl();
	}
	
	// Methods for interacting with page elements
    // ...
	public void selectSubcatogories() {
		weddingsaree.click();
	}
	public void selectColorRose() {
		dustyrose.click();
	}
	public void selectColorPink() {
		pink.click();
	}
	public void sortbyPrice() {
		DriverUtils.dropDownHandling(sortby,"Price (High > Low)");
	}
	public void clickProduct() {
		selectproduct.click();
	}
	
	/**
     * Click the "Add to Cart" button.
     */
	public void clickAddToCart() {
		addtocartbutton.click();
	}
	public void mouseoverOnCart() {
		DriverUtils.mouseOver(driverreturn(),cartmouseover);
	}
	public void clickViewCart(){
		viewcart.click();
	}
	public void clickAddQuantity(){
		addquantity.click();
	}
	public void clickUpdate(){
		update.click();
	}
	

    /**
     * Click the "Continue Shopping" link.
     */
	public void clickContinueShopping(){
		continueshopping.click();
	}
	
	/**
     * Get the text of the product in the cart.
     *
     * @return The text of the product in the cart.
     */
	public String cartProductText() {
		return DriverUtils.getText(productcheck);
	}
	
	 /**
     * Get the text of the update success alert.
     *
     * @return The text of the update success alert.
     */
	public String updateSuccessAlertText() {
		return DriverUtils.getText(updatesuccess);
	}

}
