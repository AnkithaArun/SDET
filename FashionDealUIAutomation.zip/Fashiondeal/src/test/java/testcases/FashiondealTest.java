package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.fashion.base.BaseTest;
import com.ust.fashion.base.DriverUtils;
import com.ust.fashion.pages.ContactUsPage;
import com.ust.fashion.pages.GiftPurchasePage;
import com.ust.fashion.pages.PurchaseProductPage;
//import com.ust.fashion.base.DriverUtils;
import com.ust.fashion.pages.ShowHomePage;
import com.ust.fashion.pages.UserLoginPage;
import com.ust.fashion.pages.UserRegistrationPage;
import com.ust.fashion.utils.ExcelUtils;
import com.ust.fashion.utils.FileIO;

@Listeners(com.ust.fashion.utils.SampleListener.class) 
public class FashiondealTest extends BaseTest {
	WebDriver driver;
	String[][] data;
	
	public FashiondealTest() {
		SERV_PROP_FILE = FileIO.initProperties();
	}
	/**
	 * Provides test data for the test methods.
	 *
	 * @return Object[][] containing test data.
	 */
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = ExcelUtils.testdata();
		return data;
	}

	@DataProvider(name = "testData2")
	public Object[][] testdata2() {
		data = ExcelUtils.testdata2();
		return data;
	}

	/**
	 * Test case for creating a user account with valid data.
	 *
	 * @param fname   First name of the user.
	 * @param lname   Last name of the user.
	 * @param email   Email address of the user.
	 * @param tele    Telephone number of the user.
	 * @param pass    Password for the user.
	 * @param cnfpass Confirm password for the user.
	 */

	@Test(priority = 1, dataProvider = "testData")
	public void createAccount(String fname, String lname, String email, String tele, String pass, String cnfpass) {
		ShowHomePage home = goToHomePage();
		UserRegistrationPage user = home.clickSignInlink();
		user.clickContinue();

		// Assert URL, elements
		String expected_URL = "https://fashiondeal.in/register";
		String actual_URL = user.actualURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_URL.equalsIgnoreCase(actual_URL)).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(user.driverreturn(),
					By.xpath(SERV_PROP_FILE.getProperty("checkbox")))).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(user.driverreturn(),
					By.xpath(SERV_PROP_FILE.getProperty("continuebutton")))).isTrue();
		});
		// Fill in user registration details.
		user.inputFirstName(fname);
		user.inputLastName(lname);
		user.inputEmail(email);
		user.inputTelephone(tele);
		user.inputPassword(pass);
		user.inputConfirmPassword(cnfpass);
		user.clickCheckbox();
		user.clickContinuebutton2();

		// Assert the success URL and success message.
		String expected_URL2 = "https://fashiondeal.in/index.php?route=account/success";
		String actual_URL2 = user.actualURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_URL2.equalsIgnoreCase(actual_URL2)).isTrue();
		});
		String expected_text = "Your Account Has Been Created!";
		String actual_text = user.successMsg();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_text.equalsIgnoreCase(actual_text)).isTrue();
		});

	}

	/**
	 * Test case for creating a user account with valid data without agreeing
	 * privacy policy
	 *
	 * @param fname   First name of the user.
	 * @param lname   Last name of the user.
	 * @param email   Email address of the user.
	 * @param tele    Telephone number of the user.
	 * @param pass    Password for the user.
	 * @param cnfpass Confirm password for the user.
	 */

	@Test(priority = 2, dataProvider = "testData")
	public void createAccount2(String fname, String lname, String email, String tele, String pass, String cnfpass) {
		ShowHomePage home = goToHomePage();
		UserRegistrationPage user = home.clickSignInlink();
		user.clickContinue();
		user.inputFirstName(fname);
		user.inputLastName(lname);
		user.inputEmail(email);
		user.inputTelephone(tele);
		user.inputPassword(pass);
		user.inputConfirmPassword(cnfpass);
		user.clickContinuebutton2();

		// Assert the specific error message(unchecked checkbox)
		String expected_text = "Warning: You must agree to the Privacy Policy!";
		String actual_text = user.errorMsgText();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_text.equalsIgnoreCase(actual_text)).isTrue();
		});
	}

	/**
	 * Test case for creating a user account with various invalid data scenarios.
	 */
	@Test(priority = 3)
	public void createAccount3() {
		ShowHomePage home = goToHomePage();
		UserRegistrationPage user = home.clickSignInlink();
		// Fill in invalid user registration details.
		user.clickContinue();
		user.inputFirstName("");
		user.inputLastName("");
		user.inputEmail("");
		user.inputTelephone("");
		user.inputPassword("qwerty");
		user.inputConfirmPassword("qwertyuioq");
		user.clickCheckbox();
		user.clickContinuebutton2();

		// Assert error messages for each field.
		String expected_text = "Warning: Phone Number is already registered!";
		String actual_text = user.errorMsgText();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_text.equalsIgnoreCase(actual_text)).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(user.driverreturn(), "First Name must be between 1 and 32 characters!"))
					.isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(user.driverreturn(), "Last Name must be between 1 and 32 characters!"))
					.isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(user.driverreturn(), "E-Mail Address does not appear to be valid!"))
					.isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(user.driverreturn(), "Telephone must be between 3 and 32 characters!"))
					.isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(user.driverreturn(), "Password confirmation does not match password!"))
					.isTrue();
		});
	}

	/**
	 * This method represents a test case for user login functionality on a web
	 * page.
	 *
	 * @param email    The email address to be used for login.
	 * @param password The password to be used for login.
	 */
	@Test(priority = 4, dataProvider = "testData2")
	public void UserLogin(String email, String password) {
		// Navigate to the home page and click on the "Sign In" link.
		ShowHomePage home = goToHomePage();
		UserLoginPage user = home.clickSignInlink2();
		// Verify that user navigates to login page.
		String expected_URL = "https://fashiondeal.in/login";
		String actual_URL = user.getBaseUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_URL.equalsIgnoreCase(actual_URL)).isTrue();
		});

		// Check if the text "Forgotten Password" is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(user.returnDriver(), "Forgotten Password")).isTrue();
		});
		// Check if submit button is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(user.returnDriver(),
					By.xpath(SERV_PROP_FILE.getProperty("loginbutton")))).isTrue();
		});
		// Input the provided email and password, and click the login button.
		user.inputEmail(email);
		user.inputPassword(password);
		user.clickLogin();
		// Handle different login scenarios based on provided email and password.
		if (email.equals("incorrectemail@gmail.com") && password.equals("oiutfg")) {
			String actual = "Warning: No match for E-Mail Address and/or Password.";
			String expected = user.errorMessage();
			// Verify the error message for a failed login attempt.
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
			});
		} else if (email.equals("davidjohn123@gmail.com") && password.equals("incorrectpass")) {
			String actual = "Warning: No match for E-Mail Address and/or Password.";
			String expected = user.errorMessage();
			// Verify the error message for another failed login attempt.
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(expected.equalsIgnoreCase(actual)).isTrue();
			});
		} else if (email.equals("davidjohn123@gmail.com") && password.equals("123456")) {
			// For successful login, verify that the "Account" text is present.
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(DriverUtils.isTextPresent(user.returnDriver(), "Account")).isTrue();
			});
			// Perform additional actions for a successful login, such as signing out.
			user.mouseoverAccount();
			user.clickSignOut();
		}

	}

	/**
	 * This method represents a test case for the purchase of a product on a web
	 * page. It covers the entire process from selecting a product to updating the
	 * shopping cart.
	 */
	@Test(priority = 5)
	public void purchaseProduct() {
		// Navigate to the home page and click on the "Saree" link.
		ShowHomePage home = goToHomePage();
		PurchaseProductPage product = home.clickSareelink();

		// Verify that the user is on the expected product category page.
		String expected_URL = "https://fashiondeal.in/saree/";
		String actual_URL = product.actualURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_URL.equalsIgnoreCase(actual_URL)).isTrue();
		});

		// Check if a specific element ("Wedding Sarees") is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(product.driverreturn(),
					By.xpath(SERV_PROP_FILE.getProperty("weddingsarees")))).isTrue();
		});

		// Select subcategories and verify their presence.
		product.selectSubcatogories();
		DriverUtils.delay(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(product.driverreturn(),
					By.xpath(SERV_PROP_FILE.getProperty("dustyrose")))).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isElementPresent(product.driverreturn(), By.xpath(SERV_PROP_FILE.getProperty("pink"))))
					.isTrue();
		});

		// Select colors and verify their presence.
		product.selectColorRose();
		DriverUtils.delay(2000);
		product.selectColorPink();
		DriverUtils.delay(2000);

		// Check if a specific element (sorting dropdown) is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isElementPresent(product.driverreturn(), By.xpath(SERV_PROP_FILE.getProperty("sortdropdown"))))
					.isTrue();
		});
		// Sort products by price.
		product.sortbyPrice();
		DriverUtils.delay(2000);
		product.clickProduct();

		// Click on a product and verify the product page URL.
		String expectedproduct_URL = "https://fashiondeal.in/dusty-rose-heavy-embroidered-wedding-bollywood-saree";
		String actualproduct_URL = product.actualURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedproduct_URL.equalsIgnoreCase(actualproduct_URL)).isTrue();
		});

		// Verify that the product is in stock and the "Add to Cart" button is present.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(product.driverreturn(), "In Stock")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions
					.assertThat(DriverUtils.isElementPresent(product.driverreturn(), By
							.xpath(SERV_PROP_FILE.getProperty("addtocart"))))
					.isTrue();
		});

		// Add the product to the cart.
		product.clickAddToCart();
		DriverUtils.delay(1000);
		// Verify the success notification after adding to the cart.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(product.driverreturn(),
					By.xpath(SERV_PROP_FILE.getProperty("successpopup")))).isTrue();
		});
		DriverUtils.delay(3000);

		// Mouseover the cart and click "View Cart."
		product.mouseoverOnCart();
		product.clickViewCart();
		DriverUtils.delay(2000);

		// Verify the product in the cart and update the quantity.
		String actual_product = product.cartProductText();
		String expected_product = "Dusty rose heavy embroidered wedding bollywood saree";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_product.equalsIgnoreCase(actual_product)).isTrue();
		});
		product.clickAddQuantity();
		DriverUtils.delay(2000);
		product.clickUpdate();
		DriverUtils.delay(3000);
		String actualupdate_msg = product.updateSuccessAlertText();

		// Verify the success message after updating the cart.
		String expectedupdate_msg = "Success: You have modified your shopping cart!";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualupdate_msg.contains(expectedupdate_msg)).isTrue();
		});

		// Verify the "Continue Shopping" button is displayed.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions
					.assertThat(product.driverreturn()
							.findElement(By.xpath(SERV_PROP_FILE.getProperty("continueshopping"))).isDisplayed())
					.isTrue();
		});
		// Click the "Continue Shopping" button.
		product.clickContinueShopping();
	}
	
	/**
	 * This method represents a test case for purchasing a gift certificate on a web page.
	 * It covers the process of filling out the gift purchase form and completing the purchase.
	 */	
	@Test(priority = 6)
	public void giftPurchaseTest() {
		// Navigate to the home page and click on the "Gift Purchase" link.
		ShowHomePage home = goToHomePage();
		GiftPurchasePage gift = home.clickGiftPurchaselink();
		
		 // Verify that the user is on the gift purchase page.
		String actualURL = gift.getBaseUrl();
		String expURL = "https://fashiondeal.in/index.php?route=account/voucher";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();
		});
		
		 // Fill out the gift purchase form.
		gift.inputRecpName("Adhi");
		gift.inputRecpEmail("adhi@gmail.com");
		gift.inputName("Shammi");
		gift.inputEmail("shammi@gmail.com");
		gift.themeClick();
		gift.agreeClick();
		
		// Check if the "Continue" button is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions
					.assertThat(
							DriverUtils.isElementPresent(gift.returndriver(), By.xpath(SERV_PROP_FILE.getProperty("continuebutton2"))))
					.isTrue();
		});
		
		 // Click the "Continue" button and verify the success message.
		gift.contClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(gift.returndriver(), "Thank you for purchasing a gift certificate! "))
					.isTrue();
		});
		
		 // Click the "Continue" button again to view the shopping cart.
		gift.contClick1();
		// Verify that the product is in the shopping cart and remove it.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "₹1.00 Gift Certificate for Adhi")).isTrue();
		});
		gift.removeClick();
		DriverUtils.delay(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "Your shopping cart is empty!"))
					.isTrue();
		});
		 // Click the "Continue" button to complete the purchase process.
		gift.contClick2();
	}
	
	/**
	 * This method represents a test case for gift purchase without agreeing to the terms.
	 */
	@Test(priority = 7)
	public void notclickAgree() {
		// Navigate to the home page and click on the "Gift Purchase" link.
		ShowHomePage home = goToHomePage();
		GiftPurchasePage gift = home.clickGiftPurchaselink();
		
		// Fill out the gift purchase form without agreeing to the terms.
		gift.inputRecpName("Adhi");
		gift.inputRecpEmail("adhi@gmail.com");
		gift.inputName("Shammi");
		gift.inputEmail("shammi@gmail.com");
		gift.themeClick();
		
		 // Click the "Continue" button without agreeing to the terms and verify the error message.
		gift.contClick();
		String expected_text = "Warning: You must agree that the gift certificates are non-refundable!";
		String actual_text = gift.errorMsgText();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_text.equalsIgnoreCase(actual_text)).isTrue();
		});
	}

	/**
	 * This method represents a test case for gift purchase with invalid input.
	 */
	@Test(priority = 8)
	public void continueGiftPurchase() {
		  // Navigate to the home page and click on the "Gift Purchase" link.
		ShowHomePage home = goToHomePage();
		GiftPurchasePage gift = home.clickGiftPurchaselink();
		
		// Fill out the gift purchase form with empty fields and agree to the terms.
		gift.inputRecpName("");
		gift.inputRecpEmail("");
		gift.inputName("");
		gift.inputEmail("");
		gift.agreeClick();
		
		// Click the "Continue" button and verify error messages for invalid input.
		gift.contClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(),
					"Recipient's Name must be between 1 and 64 characters!"));
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(gift.returndriver(), "E-Mail Address does not appear to be valid!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(gift.returndriver(), "Your Name must be between 1 and 64 characters!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(gift.returndriver(), "E-Mail Address does not appear to be valid!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "You must select a theme!")).isTrue();
		});
	}
	
	/**
	 * This method represents a test case for submitting a contact form on a web page.
	 * It covers the process of filling out the contact form and submitting it.
	 */
	@Test(priority = 9)
	public void contactus() {
		// Navigate to the home page and click on the "Contact Us" link.
		ShowHomePage home = goToHomePage();
		ContactUsPage contact = home.clickContactUslink();
		
		// Checking if contact us option is present
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(contact.returnDriver(),
					By.xpath(SERV_PROP_FILE.getProperty("contactuslink")))).isTrue();
		});
		
		// Checking if its redirected to correct URL after clicking Contact Us
		String expurl = "https://fashiondeal.in/contact";
		String actualurl = contact.getcurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expurl.equalsIgnoreCase(actualurl)).isTrue();
		});
		
		// Fill out the contact form.
		contact.entername("Naina");
		contact.enteremail("nainavincent@gmail.com");
		contact.dropdownclick();
		contact.entermsg("Hello I want to contact");
		
		// Check if the "Submit" button is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(contact.returnDriver(),
					By.xpath(SERV_PROP_FILE.getProperty("submitbutton")))).isTrue();
		});
		
		 // Submit the contact form and verify the success message.
		contact.submit();
		DriverUtils.delay(2000);
		String exptext = "Your message has successfully sent! we will reply as soon as possible. it may take up to 12 to 24 hours";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(exptext.equalsIgnoreCase(contact.alertMsg())).isTrue();
		});
	}
	
	
	/**
	 * This method represents a test case for submitting a contact form with an invalid email address.
	 */
	@Test(priority = 10)
	public void invalidemail() {
		// Navigate to the home page and click on the "Contact Us" link.
		ShowHomePage home = goToHomePage();
		ContactUsPage contact = home.clickContactUslink();
		
		 // Fill out the contact form with an invalid email address.
		contact.entername("Naina");
		contact.enteremail("nainavincentgmailcom");
		contact.dropdownclick();
		contact.entermsg("Hello I want to contact");
		
		// Check if the "Submit" button is present on the page.
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isElementPresent(contact.returnDriver(),
					By.xpath(SERV_PROP_FILE.getProperty("submitbutton")))).isTrue();
		});
		
		 // Submit the contact form and verify the error message for an invalid email address.
		contact.submit();
		DriverUtils.delay(2000);
		String expmsg = "E-Mail Address does not appear to be valid!";
		String actual = contact.invalidemailmsg();
		System.out.println(actual);
		// Checking if invalid mail message is displayed
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expmsg.equalsIgnoreCase(actual)).isTrue();
		});
	}
	
	/**
	 * This method represents a test case for submitting a contact form with no values in mandatory fields.
	 */
	@Test(priority = 11)
	public void novalue() {
		 // Navigate to the home page and click on the "Contact Us" link.
		ShowHomePage home = goToHomePage();
		ContactUsPage contact = home.clickContactUslink();
		
		 // Submit the contact form without providing values in mandatory fields.
		contact.submit();
		DriverUtils.delay(2000);
		
		// Verify that corresponding error messages are displayed when no value is passed to mandatory fields.
		String expnamev = "Your Name required!";
		String actualnameev = contact.noname();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expnamev.equalsIgnoreCase(actualnameev)).isTrue();
		});
		DriverUtils.delay(2000);
		String expmailv = "Your Email required!";
		String actualmailev = contact.nomail();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expmailv.equalsIgnoreCase(actualmailev)).isTrue();
		});
		DriverUtils.delay(2000);
		String expdepv = "Department required!";
		String actualdepev = contact.nodep();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expdepv.equalsIgnoreCase(actualdepev)).isTrue();
		});
		DriverUtils.delay(2000);
		String expmsgv = "Message required!";
		String actualmsgev = contact.nomsg();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expmsgv.equalsIgnoreCase(actualmsgev)).isTrue();
		});
	}
}
