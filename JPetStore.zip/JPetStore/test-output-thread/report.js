$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"e7c6a8c5-9109-49c8-a88c-9b0bd1dc4a61","feature":"Button Naviagtion","scenario":"Navigating to Fish Page","start":1692869267053,"group":1,"content":"","tags":"","end":1692869276088,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});