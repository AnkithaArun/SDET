package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class fish extends BaseUI {
	WebDriver driver;

	public fish(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and
		// this as parameters.
		PageFactory.initElements(driver, this);
	}
	
	/**********getting id of fish*************/
	@FindBy(xpath="(//div[@id=\"QuickLinks\"]//a)[1]")
	WebElement fishBtn;
	
	
	/***********Method for fish*********/
	
	public void clickFish() {
		clickOn(fishBtn);
	}

}
