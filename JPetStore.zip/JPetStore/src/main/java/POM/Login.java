package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class Login extends BaseUI {
	WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and
		// this as parameters.
		PageFactory.initElements(driver, this);
	}
	
	
	/***************Id of fish******************/
	@FindBy(xpath="(//div[@id=\"MenuContent\"]//a)[2]")
	WebElement signin;
	
	@FindBy(name="username")
	WebElement uname;
	
	@FindBy(name="password")
	WebElement upass;
	
	@FindBy(name="signon")
	WebElement loginBtn;
	
	@FindBy(xpath="//div[@id=\"Content\"]//ul//li")
	WebElement logError;
	
	/***************Id of create Account and direct to create Account******************/
	
	@FindBy(xpath="//div[@id=\"Catalog\"]//a")
	WebElement regbtn;
	
	@FindBy(name="username")
	WebElement regUname;
	
	@FindBy(name="password")
	WebElement regPass;
	
	@FindBy(name="repeatedPassword")
	WebElement regConPass;
	
	@FindBy(name="account.firstName")
	WebElement regfname;
	
	@FindBy(name="account.lastName")
	WebElement reglname;
	
	@FindBy(name="account.email")
	WebElement regEmail;
	
	@FindBy(name="account.phone")
	WebElement regPhone;
	
	@FindBy(name="account.address1")
	WebElement regAddr1;
	
	@FindBy(name="account.address2")
	WebElement regAddr2;
	
	@FindBy(name="account.city")
	WebElement regCity;
	
	@FindBy(name="account.state")
	WebElement regState;
	
	@FindBy(name="account.zip")
	WebElement regZip;
	
	@FindBy(name="account.country")
	WebElement regCntry;
	
	@FindBy(name="account.languagePreference")
	WebElement regLangPref;
	
	@FindBy(name="account.favouriteCategoryId")
	WebElement regFavDropdown;
	
	@FindBy(xpath="//*[@id=\"Catalog\"]/form/table[3]/tbody/tr[2]/td[2]/select/option[2]")
	WebElement regFavDog;
	
	@FindBy(name="account.listOption")
	WebElement regList;
	
	@FindBy(name="account.bannerOption")
	WebElement regBann;
	
	@FindBy(name="newAccount")
	WebElement regAccSubm;
	

	
	/***************Methods to login******************/
	
	public void clickSignin() {
		clickOn(signin);
	}
	
	public void clickUsername(String username) {
		sendtext(uname,username);
	}
	
	public void clickPassword(String password) {
		sendtext(upass,password);
	}
	
	public void clickLoginBtn() {
		clickOn(loginBtn);
	}
	
	public String clickLogError() {
		return getText(logError);
	}
	public void clickClear() {
	    clear(upass);
	}

	public void clickClear2(WebElement element) {
	    element.clear();
	}


	/***************Methods Register Account******************/
	
	public void clickRegbtn() {
	clickOn(regbtn);
	}
	
	public void clickRegUname(String accountname) {
		sendtext(regUname,accountname);
	}
	
	public void clickRegPass(String accPass) {
		sendtext(regPass,accPass);
	}
	
	public void clickRegConPass(String accConPass) {
		sendtext(regConPass, accConPass);
	}
	
	public void clickRegfname(String accregfname) {
		sendtext(regfname,accregfname);
	}
	
	public void clickReglname(String accreglname) {
		sendtext(reglname,accreglname);
	}
	
	public void clickRegEmail(String accregemail) {
		sendtext(regEmail,accregemail);
	}
	
	public void clickRegPhone(String accregphone) {
		sendtext(regPhone,accregphone);
	}
	
	public void clickRegAddr1(String accregaddr1) {
		sendtext(regAddr1,accregaddr1);
	}
	
	public void clickRegAddr2(String accregaddr2) {
		sendtext(regAddr2,accregaddr2);
	}
	
	public void clickRegCity(String accregcity) {
		sendtext(regCity,accregcity);
	}
	
	public void clickRegState(String accregstate) {
		sendtext(regState,accregstate);
	}
	
	public void clickRegZip(String accregzip) {
		sendtext(regZip,accregzip);
	}
	
	public void clickRegCntry(String accregcntry) {
		sendtext(regCntry,accregcntry);
	}
	
	public void dropDownHandling1() {
		clickOn(regLangPref);
	}
	
	public void dropDownHandling2() {
		clickOn(regFavDropdown);
	}
	
	public void clickDog() {
		clickOn(regFavDog);
	}
	
	public void clickRegList() {
		clickOn(regList);
	}
	
	public void clickRegBann() {
		clickOn(regBann);
	}
	
	public void clickRegsubmit() {
		clickOn(regAccSubm);
	}



}

