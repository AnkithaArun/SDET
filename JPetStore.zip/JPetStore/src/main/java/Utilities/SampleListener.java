package Utilities;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import base.BaseUI;


public class SampleListener extends TestListenerAdapter {
	public static ExtentReports extent;
	public static ExtentTest logger;

	/*********** Getting extent report instance on start of test class **********/

	public void onStart(ITestContext context) {
		extent = ExtentReportManager.getReportInstance();
	}

	/************* Creating test in extent report on start of each test ********************/
	public void onTestStart(ITestResult result) {
		logger = extent.createTest(result.getName());
		BaseUI.logger = logger;

	}

	public void onTestSuccess(ITestResult result) {
		logger.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
		logger.log(Status.PASS, "Testcase passed");
		String folderName = result.getInstanceName();
		String testName = result.getName();
		String filePath = System.getProperty("user.dir") + "//TestOutput//Screenshots//"
				+ folderName + "/" + testName + "/" + testName + "Passed.png";
		try {
			BaseUI.takeScreenShot(filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void onTestFailure(ITestResult re) {
		logger = extent.createTest(re.getName());
		MarkupHelper.createLabel(re.getName(), ExtentColor.RED);
		logger.log(Status.FAIL, "Testcase failed");
		String folderName = re.getInstanceName();
		String testName = re.getName();
		String filePath = System.getProperty("user.dir") + "//TestOutput//Screenshots//"
				+ folderName + "/" + testName + "/" + testName + "Failed.png";
		try {
			BaseUI.takeScreenShot(filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void onTestSkipped(ITestResult tr) {
		logger = extent.createTest(tr.getName());
		logger.log(Status.SKIP, MarkupHelper.createLabel(tr.getName(), ExtentColor.ORANGE));
	}

	/***************** Flushing the extent report at the end of the test class **********/
	public void onFinish(ITestContext testContext) {
		extent.flush();
	}
}
