package stepDefinitions;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import POM.fish;
import base.BaseUI;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class fishTest extends BaseUI {
	fish fsh;
	@Given("the user is on a page")
	public void the_user_is_on_a_page() {
		// driver.get("https://petstore.octoperf.com/actions/Catalog.action");
		driver = invokebrowser();
		openBrowser("applicationURL");
		fsh = new fish(driver);
	}

	@When("the user clicks on a button")
	public void the_user_clicks_on_a_button() {
		fsh.clickFish();
	}

	@Then("the user should be redirected to a new page")
    public void the_user_should_be_redirected_to_a_new_page() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.urlContains("viewCategory=&categoryId=FISH"));

        // Verify that the URL contains the expected query parameter
        String expectedQueryParameter = "viewCategory=&categoryId=FISH";
        String actualUrl = driver.getCurrentUrl();
        SoftAssertions.assertSoftly(softAssertions -> {
            softAssertions.assertThat(actualUrl).contains(expectedQueryParameter);
        });
    }

}