package testAutomate;

import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import POM.Login;
import Utilities.ExcelUtils;
import base.BaseUI;

//@Listeners(Utilities.SampleListener.class)
public class loginTestCase extends BaseUI {
	WebDriver driver;
	Login login;

	@BeforeMethod

	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");

	}

	@Test(priority = 0)
	public void userSignIn() {
		Login login = new Login(driver);
	
		login.clickSignin();
		login.clickRegbtn();
		login.clickRegUname("Akshai");
		login.clickRegPass("akshai123");
		login.clickRegConPass("akshai123");
		login.clickRegfname("Akshai");
		login.clickReglname("Biju");
		login.clickRegEmail("akshaibiju@gmail.com");
		login.clickRegPhone("8765341232");
		login.clickRegAddr1("trivandrum");
		login.clickRegAddr2("UST");
		login.clickRegCity("kulathoor");
		login.clickRegState("Kerala");
		login.clickRegZip("675432");
		login.clickRegCntry("India");
		
		login.dropDownHandling1();
		login.dropDownHandling2();
		login.clickDog();
		login.clickRegList();
		login.clickRegBann();
		login.clickRegsubmit();
	}

	@DataProvider(name = "testData")
	public Object[][] testData() {
		return ExcelUtils.testdata();
	}

	@Test(priority = 1, dataProvider = "testData")
	public void loginTest(String username, String password) throws InterruptedException {
		Login login = new Login(driver);

		login.clickSignin();
		login.clickClear();
		login.clickUsername(username);

		login.clickPassword(password);
		login.clickLoginBtn();
		String exp = login.clickLogError();

		if(username.equals(null) || password.equals(null)) {
			SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(exp.equalsIgnoreCase("Invalid username or password. Signon failed.")).isTrue();
				 });
				 }
				 else if(username.equals("incorrectUsername") && password.equals("akshai123")) {
				 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(exp.equalsIgnoreCase("Invalid username or password. Signon failed."));
				 });
				 }
				 else if(password.equals("incorrectPassword") && username.equals("AkshaiB")) {
				 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(exp.equalsIgnoreCase("Wrong password."));
				 });
				 }
				 else if(username.equals("AkshaiB") && password.equals("akshai123")) {
				 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(driver.findElement(By.id("WelcomeContent")).isDisplayed());
				 });
				 }
	}
}

//	@AfterMethod
//	public void tearDown() {
//		// Close the browser after each test method
//		driver.quit();
//	}
