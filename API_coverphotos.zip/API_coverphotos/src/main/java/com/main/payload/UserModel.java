package com.main.payload;

public class UserModel {
	
	private int id;
	private int idBook;
	private String url;
	public int getId() {
		return id;
	}
	public int getIdBook() {
		return idBook;
	}
	public void setIdBook(int idBook) {
		this.idBook = idBook;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	private int getidBook() {
		return idBook;
	}
	public void setId(int id) {
		this.id = id;
}
}