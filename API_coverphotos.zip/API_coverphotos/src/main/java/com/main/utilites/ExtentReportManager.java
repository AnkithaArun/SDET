package com.main.utilites;

import java.text.SimpleDateFormat;

import org.testng.ITestContext;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager {
	public ExtentSparkReporter sparkReporter;
	public ExtentReports extent;
	public ExtentTest Test; 
	
	String repname;
	
	public void onStart(ITestContext context) {
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
		repname = "Test-Report-"+timeStamp+".html";
		
		sparkReporter=new ExtentSparkReporter(System.getProperty("user.dir")+"/test-output/"+repname);
		sparkReporter.config().setReportName("PetStore API Automation Report");
		sparkReporter.config().setDocumentTitle("RestAssured API Automation");
		sparkReporter.config().setTheme(Theme.DARK);
		extent=new ExtentReports();
		extent.attachReporter(sparkReporter);
		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("Application", "Pet store API");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("Tester", "Jerin");
	}
	public void onFinish(ITestContext context) {
		extent.flush();
	}
	public void onTestSuccess(ITestResult result) {
		Test=extent.createTest(result.getName());
		Test.assignCategory(result.getMethod().getGroups());
		Test.createNode(result.getName());
		Test.log(Status.PASS, "Test Passed");
	}
	public void onTestFailure(ITestResult result) {
		Test=extent.createTest(result.getName());
		Test.assignCategory(result.getMethod().getGroups());
		Test.createNode(result.getName());
		Test.log(Status.FAIL, "Test Failed");
		Test.log(Status.FAIL, result.getThrowable().getMessage());
	}
	public void onTestSkipped(ITestResult result) {
		Test=extent.createTest(result.getName());
		Test.assignCategory(result.getMethod().getGroups());
		Test.createNode(result.getName());
		Test.log(Status.SKIP, "Test Skipped");
		Test.log(Status.SKIP, result.getThrowable().getMessage());
	}

	}
	
