package com.main.endpoints;

public class Routes {
	public static String baseuri="https://fakerestapi.azurewebsites.net";
	public static String post_basePath="/api/v1/CoverPhotos";
	public static String get_basePath="/api/v1/CoverPhotos/{id}";
	public static String delete_basePath="/api/v1/CoverPhotos/{id}";
	public static String put_basePath="/CoverPhotos/{id}";
	
	
	

}
