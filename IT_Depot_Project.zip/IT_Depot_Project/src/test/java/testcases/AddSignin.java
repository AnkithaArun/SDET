package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import base.baseUI;
import pom.Signin;
import utilities.ExcelUtils;


public class AddSignin extends baseUI 
{
	WebDriver driver;
	Signin signin;
	String[][] data;
	
	@BeforeTest
	public void setup()
	{
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	@DataProvider(name = "testData")
	public Object[][] testdata()
	{
		data= ExcelUtils.testdata1();
		return data;
	}
	@Test(priority=1)
	public void Accclick() {
		Signin sign = new Signin(driver);
		sign.Login();
	
	}
	
	@Test(priority=2,dataProvider = "testData")
	public void Newclick(String email,String password) {
		Signin sign = new Signin(driver);
		sign.User(email);
		sign.Password(password);
		sign.Signin();
	
		String a=driver.getCurrentUrl();
		
		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(a.contains("https://www.theitdepot.com/"));
		});	
	}
	
	@Test(priority=3)
	public void Catclick() {
		Signin sign = new Signin(driver);
		sign.Categories();	
	}
	@Test(priority=4)
	public void Gameclick() {
		Signin sign = new Signin(driver);
		sign.Gaming();	
	}
	@Test(priority=5)
	public void Checkclick() {
		Signin sign = new Signin(driver);
		sign.Check();	
	}
	
	@Test(priority=6)
	public void Dropclick() {
		Signin sign = new Signin(driver);
		sign.Dropp();
		sign.DropSelect();
	}
	@Test(priority=7)
	public void Productclick() {
		Signin sign = new Signin(driver);
		
		sign.Product();
	}
	@Test(priority=8)
	public void Logoutclick() {
		Signin sign = new Signin(driver);
		
		sign.Logout();
	}
}