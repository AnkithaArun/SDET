package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.baseUI;


public class Loginpage extends baseUI {
	private WebDriver driver;
	
	@FindBy(xpath= "//a[@class='btn btn-sm btn-info mb-2 px-2']")
	WebElement login;
	
	@FindBy(xpath="//a[@class='nav-link dropdown-toggle font-weight-bold']")
	WebElement CategoryClick;
	
	
	public Loginpage(WebDriver driver) {
		this.driver=driver;
	}
	
	public String getLoginPageTitle() {
     return driver.getTitle();
	}	
	
	public void login() {
		clickOn(login);
	}
	
	public void CategoryClick() {
		clickOn(CategoryClick);
	}
}