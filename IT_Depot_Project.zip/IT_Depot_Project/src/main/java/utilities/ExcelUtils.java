package utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils
{

	public static String[][] testdata1() {
	    FileInputStream fis;
	    XSSFWorkbook workbook=null;
	        try
	        {
	        fis=new FileInputStream("C:\\JAVA_SDET\\DATA\\java_sdet\\IT_Depot_Project\\src\\test\\java\\resources\\Test2.xlsx");
	        workbook=new XSSFWorkbook(fis);
	        }
	        catch(IOException e)
	        {
	            e.printStackTrace();
	        }

	        XSSFSheet sheet=workbook.getSheetAt(0);
	        int rowCount=sheet.getPhysicalNumberOfRows();
	        System.out.println("Total number of rows used in sheet: "+rowCount);
	        int colCount=sheet.getRow(0).getPhysicalNumberOfCells();
	        System.out.println("Total number of columns used in sheet: "+colCount);
	        String[][] testdata=new String[rowCount][colCount];
	        for (int i = 0; i < rowCount; i++) {
	            for (int j = 0; j < colCount; j++) {

	                testdata[i][j]=sheet.getRow(i).getCell(j).getStringCellValue();
	            }

	        }
	        return testdata;

	 

	    }

	

}
