$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"ea5c0bdc-18d5-4bcd-9c59-1568283423ad","feature":"Login page feature","scenario":"Login page title","start":1691595146478,"group":1,"content":"","tags":"","end":1691595157916,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});