package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload_books.UserModel_books;

public class UserEndpoints_books 
{

	public static Response createUser(UserModel_books payload)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response=RestAssured.given()
				.baseUri(Routes_books .baseuri)
				.basePath(Routes_books .post_basePath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
	}
	 public static Response  getUser(int ide)
	 {
		 RestAssured.useRelaxedHTTPSValidation();
		 Response response=RestAssured.given()
					.baseUri(Routes_books .baseuri)
					.basePath(Routes_books .get_basePath)
					.pathParam("id",ide)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.when()
					.get();
		 return response;
	 }
	 public static Response deleteUser(int ide)
		{
		 RestAssured.useRelaxedHTTPSValidation();
			Response response=RestAssured.given()
					.baseUri(Routes_books .baseuri)
					.basePath(Routes_books .delete_basePath)
					.pathParam("id",ide)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.when()
					.delete();
			return response;
		}
	 public static Response updateUser(int  ide,UserModel_books payload)
		{
		 RestAssured.useRelaxedHTTPSValidation();
			Response response=RestAssured.given()
					.baseUri(Routes_books .baseuri)
					.basePath(Routes_books .update_basePath)
					.pathParam("id",ide)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.body(payload)
					.when()
					.put();
			return response;
		}
}
