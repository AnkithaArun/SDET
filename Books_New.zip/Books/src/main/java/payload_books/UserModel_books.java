package payload_books;

public class UserModel_books 
{
	private int id;
	private String title;
	private String description;
	private int pageCount;
	private String excerpt;
	private String publishDate;
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getTitle() 
	{
		return title;
	}
	public void setTitle(String title) 
	{
		this.title = title;
	}
	public String getDescription() 
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	public int getPageCount() 
	{
		return pageCount;
	}
	public void setPageCount(int i)
	{
		this.pageCount = i;
	}
	public String getExcerpt()
	{
		return excerpt;
	}
	public void setExcerpt(String excerpt)
	{
		this.excerpt = excerpt;
	}
	public String getPublishDate()
	{
		return publishDate;
	}
	public void setPublishDate(String publishDate) 
	{
		this.publishDate = publishDate;
	}
	
	

}
