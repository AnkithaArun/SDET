package testcases_books;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.UserEndpoints_books;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload_books.UserModel_books;
import utilities.Dataprovider_books;

@Listeners(utilities.Extentmanager_books.class)
public class Datadriventest_books
{

	@Test(priority=1,dataProvider="data",dataProviderClass=Dataprovider_books.class)
	public void testPostUser(String id,String tit,String des,String cou,String excer,String datee)
	{
		RestAssured.useRelaxedHTTPSValidation();
		UserModel_books  user=new UserModel_books ();
		user.setId(Integer.parseInt(id));
		user.setTitle(tit);
		user.setDescription(des);
		user.setPageCount(Integer.parseInt(cou));
		user.setExcerpt(excer);
		user.setPublishDate(datee);
		
		Response response=UserEndpoints_books .createUser(user);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority = 2,dataProvider = "ids",dataProviderClass = Dataprovider_books.class)
	public void testDeleteById(String id)
	{
		Response response=UserEndpoints_books.deleteUser(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	@Test(priority=3,dataProvider="ids",dataProviderClass=Dataprovider_books.class)
    public void testGetUserById(String id)
{
//RestAssured.useRelaxedHTTPSValidation();
Response response = UserEndpoints_books.getUser(Integer.parseInt(id));
       response.then().log().all();
Assert.assertEquals(response.getStatusCode(),200);
}
   @Test(priority = 4,dataProvider="updates",dataProviderClass=Dataprovider_books.class)
    public void testUpdateuserById(String id,String tit,String des,String cou,String excer,String datee)
   {
	   //RestAssured.useRelaxedHTTPSValidation();
	   UserModel_books  user=new UserModel_books ();
	   user.setId(Integer.parseInt(id));
		user.setTitle(tit);
		user.setDescription(des);
		user.setPageCount(Integer.parseInt(cou));
		user.setExcerpt(excer);
		user.setPublishDate(datee);
	   Response response = UserEndpoints_books.updateUser(Integer.parseInt(id),user);
        response.then().log().all();
        Assert.assertEquals(response.getStatusCode(),200);
   }
}

